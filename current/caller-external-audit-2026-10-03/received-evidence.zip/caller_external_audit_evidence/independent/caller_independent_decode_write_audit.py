import json, pathlib, subprocess, re, collections
ROOT=pathlib.Path('/mnt/data/caller_audit_work/snapshot'); CT=ROOT/'runtime_trace/caller_transition'
MODMAP={
 'a6ac98736304bb9f6a92e473bba45da10d9b5b99f8019e2ca15eb6a7f86234fc': ROOT/'audit/gate2c1/vendor/gala/integrate/cyintegrators/leapfrog.cpython-312-x86_64-linux-gnu.so',
 '3a15d66867d83762c7f2f1e37359cb8f6c5743edb369c65285cb0b1c4f7498bf': ROOT/'runtime_trace/frozen_binaries/libc.so.6',
 'e50d468e8b0adfb05733f5b87b3cff34829c4a8c1aea50c865aa8bdfe4bb150f': CT/'frozen_modules/python3.12',
}
CASES=['audited-attempt-05-readproof-01','fresh-closure-fresh-01-readproof-01']
rows0=[json.loads(x) for x in open(CT/'artifacts'/CASES[0]/'caller_trace.jsonl')]
by=collections.defaultdict(dict)
for r in rows0: by[r['module_sha256']][r['elf_address']]=r
pat=re.compile(r'^\s*([0-9a-fA-F]+):\s+((?:[0-9a-fA-F]{2}\s+)+)\s*(.*)$')
dec={}
for h,targets in by.items():
 lo=min(targets)-16; hi=max(targets)+32
 p=subprocess.Popen(['objdump','-d','--insn-width=16',f'--start-address={lo}',f'--stop-address={hi}',str(MODMAP[h])],stdout=subprocess.PIPE,text=True,errors='replace')
 for line in p.stdout:
  m=pat.match(line)
  if m and int(m.group(1),16) in targets:
   dec[(h,int(m.group(1),16))]=m.group(3).strip()
 if p.wait()!=0: raise SystemExit('objdump failed')

def hx(x): return int(x,16) if isinstance(x,str) else int(x)
def regv(pre, reg):
 r=reg.lstrip('%'); amap={'eax':'rax','ebx':'rbx','ecx':'rcx','edx':'rdx','esi':'rsi','edi':'rdi','ebp':'rbp','esp':'rsp','r8d':'r8','r9d':'r9','r10d':'r10','r11d':'r11','r12d':'r12','r13d':'r13','r14d':'r14','r15d':'r15'}; r=amap.get(r,r); return hx(pre['gpr'][r])
def s64(x): return x-(1<<64) if x&(1<<63) else x
def pea(op,pre):
 op=op.strip(); seg=None
 if op.startswith('%fs:') or op.startswith('%gs:'): seg=op[1:3]; op=op[4:]
 if '(' not in op:
  d=int(op,0); d=s64(d) if op.lower().startswith('0x') and d>=1<<63 else d; base=0
 else:
  ds,rest=op.split('(',1); rest=rest.rstrip(')'); d=int(ds,0) if ds not in ('','+') else 0; ps=[z.strip() for z in rest.split(',')]; base=regv(pre,ps[0]) if ps and ps[0] else 0; idx=regv(pre,ps[1]) if len(ps)>1 and ps[1] else 0; sc=int(ps[2],0) if len(ps)>2 and ps[2] else 1; base+=idx*sc
 if seg: base+=hx(pre['segment_bases'][seg+'_base'])
 return (base+d)&((1<<64)-1)
def split_asm(asm):
 asm=asm.split('#',1)[0].strip()
 if asm.startswith('lock '):
  z=asm[5:].strip(); m,_,ops=z.partition(' '); return 'lock '+m,ops.strip()
 m,_,ops=asm.partition(' '); return m,ops.strip()
def opsplit(s):
 out=[];c='';d=0
 for ch in s:
  if ch=='(':d+=1
  elif ch==')':d-=1
  if ch==',' and d==0:out.append(c.strip());c=''
  else:c+=ch
 if c.strip():out.append(c.strip())
 return out
def memop(s): return '(' in s or s.startswith('%fs:') or s.startswith('%gs:')
def iswrite(asm):
 m,o=split_asm(asm); a=opsplit(o)
 if m in ('call','push'):return True
 return m in ('mov','movl','movq','movsd','vmovdqu','add','addl','subl','andb','xchg','lock cmpxchg') and a and memop(a[-1])
def rw(reg):
 r=reg.lstrip('%')
 if r in {'al','bl','cl','dl','sil','dil'}:return 1
 if r in {'eax','ebx','ecx','edx','esi','edi','ebp','esp'} or r.endswith('d') and r.startswith('r'):return 4
 if r.startswith('xmm'):return 16
 return 8
def easz(asm,pre):
 m,o=split_asm(asm); a=opsplit(o)
 if m in ('call','push'):return (regv(pre,'%rsp')-8)&((1<<64)-1),8
 ea=pea(a[-1],pre)
 sz={'vmovdqu':16,'movsd':8,'movl':4,'addl':4,'subl':4,'movq':8,'andb':1}.get(m)
 if sz is None: sz=rw(a[0])
 return ea,sz

def ov(a,n,b,m):return max(a,b)<min(a+n,b+m)
out={}
for case in CASES:
 rows=[json.loads(x) for x in open(CT/'artifacts'/case/'caller_trace.jsonl')]; cap=json.load(open(CT/'artifacts'/case/'capture.json'))
 derived=[]; missing=[]; eaerr=[]
 for r in rows:
  asm=dec[(r['module_sha256'],r['elf_address'])]
  if iswrite(asm):
   ea,sz=easz(asm,r['pre']); derived.append((r['sequence'],ea,sz,asm))
   w=r['possible_memory_writes']
   if len(w)!=1 or w[0]['address']!=ea or w[0]['size']!=sz:eaerr.append((r['sequence'],asm,ea,sz,w))
  elif r['possible_memory_writes']:missing.append((r['sequence'],asm,r['possible_memory_writes']))
 p=cap['first_step_entry']['abi']['pointers']; ovs=[]
 for seq,ea,sz,asm in derived:
  for name in ['q','full_v','latent']:
   if ov(ea,sz,p[name],16):ovs.append((seq,name,asm,ea,sz,p[name]))
 out[case]={'objdump_derived_writes':len(derived),'effect_field_unexpected_writes':missing,'ea_or_size_errors':eaerr,'carry_overlaps':ovs}
print(json.dumps(out,indent=2))
pathlib.Path('/mnt/data/caller_independent_decode_write_results.json').write_text(json.dumps(out,indent=2)+'\n')
