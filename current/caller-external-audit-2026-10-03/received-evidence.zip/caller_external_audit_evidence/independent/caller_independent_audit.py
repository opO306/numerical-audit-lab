import json, hashlib, pathlib, re, subprocess, struct, sys
ROOT=pathlib.Path('/mnt/data/caller_audit_work/snapshot')
CT=ROOT/'runtime_trace/caller_transition'
CASES=['audited-attempt-05-readproof-01','fresh-closure-fresh-01-readproof-01']
MODMAP={
 'a6ac98736304bb9f6a92e473bba45da10d9b5b99f8019e2ca15eb6a7f86234fc': ROOT/'audit/gate2c1/vendor/gala/integrate/cyintegrators/leapfrog.cpython-312-x86_64-linux-gnu.so',
 '3a15d66867d83762c7f2f1e37359cb8f6c5743edb369c65285cb0b1c4f7498bf': ROOT/'runtime_trace/frozen_binaries/libc.so.6',
 'e50d468e8b0adfb05733f5b87b3cff34829c4a8c1aea50c865aa8bdfe4bb150f': CT/'frozen_modules/python3.12',
}

def sha(p): return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def hx(x): return int(x,16) if isinstance(x,str) else int(x)
def signed64(x):
    x &= (1<<64)-1
    return x-(1<<64) if x&(1<<63) else x

def regv(pre, reg):
    reg=reg.lstrip('%')
    # normalize 32-bit aliases to their 64-bit container values for address calc
    amap={'eax':'rax','ebx':'rbx','ecx':'rcx','edx':'rdx','esi':'rsi','edi':'rdi','ebp':'rbp','esp':'rsp',
          'r8d':'r8','r9d':'r9','r10d':'r10','r11d':'r11','r12d':'r12','r13d':'r13','r14d':'r14','r15d':'r15'}
    reg=amap.get(reg,reg)
    return hx(pre['gpr'][reg])

def parse_ea(op, pre):
    op=op.strip()
    seg=None
    if op.startswith('%fs:') or op.startswith('%gs:'):
        seg=op[1:3]; op=op[4:]
    # absolute or disp(base,index,scale)
    if '(' not in op:
        disp=int(op,0)
        if op.lower().startswith('0x') and disp >= 1<<63: disp=signed64(disp)
        base=0
    else:
        disp_s,rest=op.split('(',1); rest=rest.rstrip(')')
        disp=0 if disp_s in ('','+') else int(disp_s,0)
        parts=[x.strip() for x in rest.split(',')]
        base=regv(pre,parts[0]) if parts and parts[0] else 0
        idx=regv(pre,parts[1]) if len(parts)>1 and parts[1] else 0
        scale=int(parts[2],0) if len(parts)>2 and parts[2] else 1
        base += idx*scale
    if seg:
        base += hx(pre['segment_bases'][seg+'_base'])
    return (base+disp) & ((1<<64)-1)

def split_asm(asm):
    asm=asm.split('#',1)[0].strip()
    if asm.startswith('lock '):
        rest=asm[5:].strip(); m,_,ops=rest.partition(' '); return 'lock '+m, ops.strip()
    m,_,ops=asm.partition(' '); return m.strip(), ops.strip()

def is_mem_operand(op): return '(' in op or op.startswith('%fs:') or op.startswith('%gs:')
def split_ops(ops):
    # no commas inside anything except address parens, so depth-aware
    out=[]; cur=''; d=0
    for c in ops:
        if c=='(' : d+=1
        elif c==')': d-=1
        if c==',' and d==0: out.append(cur.strip()); cur=''
        else: cur+=c
    if cur.strip() or ops=='': out.append(cur.strip())
    return out

def potential_write(asm):
    m,ops=split_asm(asm); a=split_ops(ops)
    if m in ('call','push'): return True
    if m in ('mov','movl','movq','movsd','vmovdqu','add','addl','subl','andb','xchg','lock cmpxchg'):
        return bool(a and is_mem_operand(a[-1]))
    return False

def reg_width(reg):
    r=reg.strip().lstrip('%')
    if r in ('al','bl','cl','dl','sil','dil') or r.endswith('b') and r.startswith('r'): return 1
    if r in ('ax','bx','cx','dx','si','di','bp','sp') or r.endswith('w') and r.startswith('r'): return 2
    if r in ('eax','ebx','ecx','edx','esi','edi','ebp','esp') or r.endswith('d') and r.startswith('r'): return 4
    if r.startswith('xmm'): return 16
    return 8

def write_ea_size(asm,pre):
    m,ops=split_asm(asm); a=split_ops(ops)
    if m in ('call','push'):
        return (regv(pre,'%rsp')-8)&((1<<64)-1),8
    dst=a[-1]
    ea=parse_ea(dst,pre)
    if m=='vmovdqu': sz=16
    elif m=='movsd': sz=8
    elif m in ('movl','addl','subl'): sz=4
    elif m=='movq': sz=8
    elif m=='andb': sz=1
    elif m=='lock cmpxchg': sz=reg_width(a[0])
    elif m=='xchg': sz=reg_width(a[0])
    elif m in ('mov','add'):
        sz=reg_width(a[0]) if a and a[0].startswith('%') else 8
    else: raise AssertionError((m,asm))
    return ea,sz

def overlap(a,n,b,m): return max(a,b) < min(a+n,b+m)

def le_hex_to_u64(h):
    b=bytes.fromhex(h); assert len(b)==8; return struct.unpack('<Q',b)[0]

results={}
for case in CASES:
    b=CT/'artifacts'/case
    cap=json.load(open(b/'capture.json'))
    seal=json.load(open(b/'acquisition_seal.json'))
    # seal exact file hashes
    seal_ok=True
    for name,expect in seal['sealed_files'].items():
        if sha(b/name)!=expect: seal_ok=False
    trace_path=b/'caller_trace.jsonl'
    rows=[json.loads(x) for x in open(trace_path)]
    dense=[r['sequence'] for r in rows]==list(range(len(rows)))
    # module hashes and raw bytes at file offsets
    byte_errors=[]; pc_errors=[]; modhash={}
    for h,p in MODMAP.items(): modhash[h]=sha(p)
    for r in rows:
        p=MODMAP[r['module_sha256']]
        raw=bytes.fromhex(r['instruction_bytes'])
        with open(p,'rb') as f:
            f.seek(r['file_offset']); got=f.read(len(raw))
        if got!=raw: byte_errors.append(r['sequence'])
        if r['pc'] != r['load_base'] + r['elf_address']: pc_errors.append(r['sequence'])
    # independent write completeness from recorded decoded assembly, plus EA derivation independent of recorded effects
    exp_write=[r['sequence'] for r in rows if potential_write(r['assembly'])]
    rec_write=[r['sequence'] for r in rows if r['possible_memory_writes']]
    ea_err=[]; size_err=[]
    derived=[]
    for r in rows:
        if not potential_write(r['assembly']): continue
        ea,sz=write_ea_size(r['assembly'],r['pre'])
        derived.append((r['sequence'],ea,sz))
        ws=r['possible_memory_writes']
        if len(ws)!=1 or ws[0]['address']!=ea: ea_err.append((r['sequence'],ea,ws))
        elif ws[0]['size']!=sz: size_err.append((r['sequence'],sz,ws[0]['size']))
    fptr=cap['first_step_entry']['abi']['pointers']; sptr=cap['second_step_entry']['abi']['pointers']
    ptr_identity={k:(fptr[k]==sptr[k]) for k in ['q','full_v','latent','gradient']}
    carry_regions=[('q',fptr['q'],16),('full_v',fptr['full_v'],16),('latent',fptr['latent'],16)]
    overlaps=[]
    for seq,ea,sz in derived:
        for name,addr,n in carry_regions:
            if overlap(ea,sz,addr,n): overlaps.append((seq,name,ea,sz,addr,n))
    fr=cap['first_step_return']['post_component_bits']; se=cap['second_step_entry']['abi']['component_bits']
    carry_bits_equal={k:fr[k]==se[k] for k in ['q','full_v','latent']}
    # gradient exact zero path
    grad_rows=[rows[714],rows[715]]
    grad_zero=(all(x['pre']['xmm']['xmm0']=='0x00000000000000000000000000000000' for x in grad_rows)
               and all(write_ea_size(x['assembly'],x['pre'])==(sptr['gradient'],16) for x in grad_rows)
               and se['gradient']==['0x0000000000000000','0x0000000000000000'])
    # t/dt receipts from raw observations and register state
    r718=rows[718]; r723=rows[723]
    t_obs=r718['pre_memory_observations'][0]; dt_obs=r723['pre_memory_observations'][0]
    t_ea=parse_ea('0x0(%r13)',r718['pre']); dt_ea=parse_ea('0x108(%rsp)',r723['pre'])
    t_bits=f"0x{le_hex_to_u64(t_obs['bytes_hex']):016x}"; dt_bits=f"0x{le_hex_to_u64(dt_obs['bytes_hex']):016x}"
    t_ok=(t_obs['address']==t_ea and t_bits=='0x3fa0000000000000' and r718['post']['xmm']['xmm0'].endswith(t_bits[2:]) and cap['second_step_entry']['abi']['t_bits']==t_bits)
    dt_ok=(dt_obs['address']==dt_ea and dt_bits=='0x3f90000000000000' and r723['post']['xmm']['xmm1'].endswith(dt_bits[2:]) and cap['second_step_entry']['abi']['dt_bits']==dt_bits)
    # final ABI pointer registers and call edge
    rr=rows[727]['pre']['gpr']
    abi_ok=(hx(rr['rcx'])==sptr['q'] and hx(rr['r8'])==sptr['full_v'] and hx(rr['r9'])==sptr['latent']
            and rows[727]['next_pc']==cap['second_step_entry']['abi']['entry_pc']
            and cap['controlled_stop_receipt']['second_step_body_instructions_executed']==0)
    # antecedent hash and binding data checks
    case_trans='artifacts/producer-fix-round2/'+case+'/transition.json'
    tr=json.load(open(CT/case_trans))
    irp=ROOT/tr['antecedent']['numeric_ir_path']; cop=ROOT/tr['antecedent']['correspondence_path']
    antecedent_hash=(sha(irp)==tr['antecedent']['numeric_ir_sha256'] and sha(cop)==tr['antecedent']['correspondence_sha256'])
    ir=json.load(open(irp)); co=json.load(open(cop))
    vals={x['value_id']:x for x in ir['values']}
    sb={x['state_id']:x for x in co['state_bindings']}
    bind_err=[]
    for bind in tr['bindings']['carry']:
        vid=bind['endpoint_memory_value_id']; vv=vals.get(vid)
        if vv is None or vv['raw_bits']!=bind['center_bits']: bind_err.append((vid,'center'))
        # memory storage must match component/offset
        if vv is None or vv['storage']['space']!='buffer' or vv['storage']['name']!=bind['component'] or vv['storage']['byte_offset']!=bind['byte_offset']:
            bind_err.append((vid,'storage'))
        fs=sb.get(bind['form_source_state_id'])
        if fs is None or fs['raw_center_bits']!=bind['center_bits'] or fs['form']!=bind['form']:
            bind_err.append((vid,'form'))
        # If memory value is a copy, confirm its immediate source id matches declared copy source
        if vv and vv['producer_kind']=='COPY_BITS':
            if len(vv['source_slices'])!=1 or vv['source_slices'][0]['value_id']!=bind['copy_source_value_id']:
                bind_err.append((vid,'copy_source'))
    results[case]={
      'seal_ok':seal_ok,'trace_sha_ok':sha(trace_path)==cap['trace_sha256'],'record_count':len(rows),'dense_sequence':dense,
      'module_hashes_ok':all(k==v for k,v in modhash.items()),'instruction_file_bytes_mismatch':byte_errors,'pc_mapping_errors':pc_errors,
      'derived_write_count':len(exp_write),'recorded_write_count':len(rec_write),'write_sequence_sets_equal':exp_write==rec_write,
      'write_ea_errors':ea_err,'write_size_errors':size_err,'same_value_write_count':sum(1 for r in rows for w in r['possible_memory_writes'] if not w['value_changed']),
      'pointer_identity':ptr_identity,'carry_bits_equal':carry_bits_equal,'carry_write_overlaps':overlaps,'gradient_exact_zero':grad_zero,
      'time_load_ok':t_ok,'dt_load_ok':dt_ok,'final_abi_and_stop_ok':abi_ok,'antecedent_hash_ok':antecedent_hash,'binding_errors':bind_err,
    }
print(json.dumps(results,indent=2,sort_keys=True))
out=pathlib.Path('/mnt/data/caller_independent_audit_results.json'); out.write_text(json.dumps(results,indent=2,sort_keys=True)+'\n')
