import json, pathlib, subprocess, re, collections
ROOT=pathlib.Path('/mnt/data/caller_audit_work/snapshot')
CT=ROOT/'runtime_trace/caller_transition'
case='audited-attempt-05-readproof-01'
rows=[json.loads(x) for x in open(CT/'artifacts'/case/'caller_trace.jsonl')]
MODMAP={
 'a6ac98736304bb9f6a92e473bba45da10d9b5b99f8019e2ca15eb6a7f86234fc': ROOT/'audit/gate2c1/vendor/gala/integrate/cyintegrators/leapfrog.cpython-312-x86_64-linux-gnu.so',
 '3a15d66867d83762c7f2f1e37359cb8f6c5743edb369c65285cb0b1c4f7498bf': ROOT/'runtime_trace/frozen_binaries/libc.so.6',
 'e50d468e8b0adfb05733f5b87b3cff34829c4a8c1aea50c865aa8bdfe4bb150f': CT/'frozen_modules/python3.12',
}
by=collections.defaultdict(dict)
for r in rows: by[r['module_sha256']][r['elf_address']]=r
pat=re.compile(r'^\s*([0-9a-fA-F]+):\s+((?:[0-9a-fA-F]{2}\s+)+)\s*(.*)$')
errs=[]; found=0
for h,targets in by.items():
    lo=min(targets)-16; hi=max(targets)+32
    cmd=['objdump','-d','--insn-width=16',f'--start-address={lo}',f'--stop-address={hi}',str(MODMAP[h])]
    p=subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,errors='replace')
    got={}
    for line in p.stdout:
        m=pat.match(line)
        if not m: continue
        addr=int(m.group(1),16)
        if addr not in targets: continue
        bs=''.join(m.group(2).split()).lower()
        asm=m.group(3).strip()
        got[addr]=(bs,asm)
    stderr=p.stderr.read(); rc=p.wait()
    if rc: raise SystemExit((rc,stderr[:500]))
    for addr,r in targets.items():
        if addr not in got:
            errs.append((r['sequence'],'not_decoded',hex(addr))); continue
        found+=1; bs,asm=got[addr]
        if bs!=r['instruction_bytes'].lower(): errs.append((r['sequence'],'bytes',bs,r['instruction_bytes']))
        # compare primary mnemonic incl lock prefix
        def mn(s):
            s=s.strip();
            if s.startswith('lock '):
                z=s[5:].strip().split(None,1)[0]; return 'lock '+z
            return s.split(None,1)[0] if s else ''
        if mn(asm)!=mn(r['assembly']): errs.append((r['sequence'],'mnemonic',mn(asm),mn(r['assembly']),asm,r['assembly']))
print(json.dumps({'target_rows':len(rows),'decoded_rows':found,'errors':errs[:50],'error_count':len(errs)},indent=2))
pathlib.Path('/mnt/data/caller_decode_check_results.json').write_text(json.dumps({'target_rows':len(rows),'decoded_rows':found,'errors':errs,'error_count':len(errs)},indent=2)+'\n')
