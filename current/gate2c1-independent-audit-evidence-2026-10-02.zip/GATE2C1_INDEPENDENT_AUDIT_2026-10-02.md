# Gate 2C.1 Independent Audit — 2026-10-02

## 결론 요약

- 전달 ZIP SHA-256: `b3adbc940d7c819a87f2366bb36c10a0e67597976bb9b85f3c50503ef85c261d` — 사용자 제시값과 정확히 일치.
- 기준 Git HEAD: `bb436647ee76a0bd73dfd108f4db8d295a17d61f` — bundle fresh clone HEAD와 정확히 일치.
- A1–A11: **전부 PASS**.
- Critical: 0
- Major: 0
- Minor: 0
- UNRESOLVED: 1 — ZIP 외부 delivery triplet(`DELIVERY.md`, `delivery_receipt.json`, `gate2c1-complete-audit-2026-10-02.zip.sha256`)이 전달되지 않아 실제 sidecar 상호일치를 독립 확인할 수 없음.
- 최종 판정: **CONDITIONAL**.

`Critical 0 / Major 0 / UNRESOLVED 0` 조건이 아니므로 현재 자료만으로 Gate 2C 계열을 최종 `CLOSED / PASS`로 올릴 수 없다. 현재 확인된 유일한 closure blocker는 위 외부 delivery triplet의 실물 부재다.

---

## 감사 독립성

감사자는 Gate 2C / Gate 2C.1 producer evaluator, 판정 함수, 저장 checkpoint를 정답으로 사용하지 않았다. 별도 checker를 `/mnt/data/gate2c1_audit_work/`에 작성했고, 허용된 frozen V2 연산자(`lab.v2_bound`)만 호출했다. binary64 실행은 actual `.so`/source를 먼저 독립 확인한 뒤 감사 checker 안에 별도 전사했으며, 각 산술연산은 `Fraction`에서 정확히 계산한 뒤 IEEE-754 binary64 round-to-nearest-ties-to-even으로 반올림했다.

최종 주요 감사 산출물 SHA-256:

- `independent_audit.py`: `898b7ead668e3f1560967a1841a885511ec5f93b2cb39a3869a880f30a90667e`
- `final_independent_results.json`: `0feb3e31e1121a2d820e6f7f97309655961a409605b81b954908bb5b7be460bb`
- `exact_window_independent.py`: `c15dcda8dcad35ba5674821b9dcc1134e7da4441f58d28c1c19e9295d4549f5c`
- `exact_window_independent_results.json`: `e398b4b0af8ca16eb129fe5fa0a016422f94eee01cf6b2848891b20f38d235db`
- `pytest_full.log`: `24bd2184aa4f9f09cff89a57c674467915adee061dad9c34089073b20329f4a9`

감사 도중 감사자 checker 자체에서 두 번의 표현/직렬화 문제가 발견되어 수정했다. 첫째, 거대한 exact Fraction을 10진 문자열로 직렬화하다 Python의 최대 자릿수 제한에 걸린 문제를 numerator/denominator 16진 기록으로 바꿨다. 둘째, Lab bound 사망 뒤 producer는 invalid Form을 snapshot에는 보존하되 다시 사용하지 않는데, 최초 감사 checker는 이를 `None`으로 지워 14000 이후 snapshot만 달라졌다. 이를 “보존하되 재사용 금지”라는 실제 runner 상태 의미론대로 수정한 뒤 chaotic 1..100000을 다시 전파했다. 수정 후 endpoint/digest/chain mismatch는 모두 0이었다. 두 문제 모두 대상 package의 수치 finding이 아니라 감사자 도구의 문제이며 공개 기록했다.

---

## A1

```yaml
A1: PASS
근거:
  - ZIP 내 실제 wheel SHA-256은 cc5f0cf3bc63a966a3c130b93f6c05026271fe7178492a02c6266c243b5fc2f0.
  - 실제 leapfrog .so SHA-256은 a6ac98736304bb9f6a92e473bba45da10d9b5b99f8019e2ca15eb6a7f86234fc.
  - 실제 cybuiltin .so SHA-256은 33d66d82c34c717560747ffbfca1d98f97432a0a671a0a210a0a225d8367ecaf.
  - wheel 내부 해당 두 .so와 audit/gate2c1/vendor의 별도 .so 사본은 byte-for-byte 동일.
  - frozen capture는 N=1, ndim=2, default zero origin/identity rotation이고 c_gradient의 no-transform direct callback 경로를 탄다.
  - actual cybuiltin .so에서 cmp rcx,1 @1ca65, je @1ca69 -> 1cb60이 확인되어 N=1은 odd/vector의 (x+x)*y 경로가 아니라 1cb85 이후 loop 경로를 탄다.
  - 실제 gradient 산술 순서는 1cb85 MUL y*x, 1cb89 ADD gz+x, 1cb8d MUL x*x, 1cb91 ADD xy+xy, 1cb95 ADD dbl+ax, 1cba3 MUL y*y, 1cba7 ADD y+gz, 1cbac SUB xx-yy, 1cbb0 ADD diff+ay.
  - 문제의 doubling은 명확히 (x*y)+(x*y)이며 (x+x)*y가 아니다.
  - leapfrog init은 15941 MUL dt*half, 15993 MUL grad*hhalf, 15997 SUB velocity-kick 순서.
  - step은 1580b MUL dt*vh, 15818 ADD position, gradient callback, 15855 MUL dt*half, 1588e/15892 output full velocity, 158a1/158ac next latent velocity 순서.
  - .rodata 0x3b360의 bytes는 little-endian 000000000000e03f = binary64 0.5.
  - gradient accumulator zero는 memset에서 오며 mapping에서 산술 instruction으로 위장되지 않고 load/initialization(CONST gz=0)으로만 표현된다.
독립 검증 방법:
  - ZIP의 실제 ELF에 objdump를 직접 실행하고 frozen Cython/C++ source의 call routing과 대조.
  - machine_mapping의 정적 address/op/operand를 실제 instruction과 하나씩 대조.
재현 명령 또는 checker:
  - objdump -d audit/gate2c1/vendor/.../cybuiltin...so
  - objdump -d audit/gate2c1/vendor/.../leapfrog...so
  - objdump -s -j .rodata --start-address=0x3b360 --stop-address=0x3b368 <leapfrog.so>
발견된 문제: 없음
```

## A2

```yaml
A2: PASS
근거:
  - machine_mapping의 init 17개, step 25개 row에서 T_bin과 V2_trace가 전부 동일.
  - 별도 exact-rounding executor로 regular/chaotic 각각 init 및 step1의 모든 operation을 다시 계산했다.
  - 각 operation의 ordinal, machine_address, dynamic occurrence, op, dst, operands, literal, operand_bits, result_bits 불일치 0.
  - regular step1 예: 1cb85 xys=0x3ee0000000000000, 1cb91 dbls=0x3ef0000000000000. 이는 먼저 x*y를 계산한 뒤 동일 intermediate를 더한 결과다.
  - old doubling graph, constant 변경, op order 변경, intermediate operand 변경을 각각 주입했을 때 sealed structure 검사가 모두 거부.
  - 독립 100k 전파에서 producer segment decision digest mismatch 0.
독립 검증 방법:
  - 실제 machine에서 전사한 별도 BIN_INIT/BIN_STEP graph를 exact Fraction -> binary64 RN-even으로 실행.
  - 저장 trace의 operand/result bits를 operation마다 독립 재계산.
  - 매 step의 독립 decision encoding으로 각 1000-step segment digest를 재계산.
재현 명령 또는 checker:
  - /mnt/data/gate2c1_audit_work/independent_audit.py
  - direct mutation check: old_graph / constant / order / intermediate 모두 DETECTED
발견된 문제: 없음
```

## A3

```yaml
A3: PASS
근거:
  - 전달 ZIP 자체 SHA-256은 b3adbc940d7c819a87f2366bb36c10a0e67597976bb9b85f3c50503ef85c261d로 제시값과 일치.
  - ZIP entry는 646개: manifest가 광고하는 파일 645개 + PACKAGE_MANIFEST.json 1개.
  - advertised 645개: missing 0, byte-hash mismatch 0, unmanifested member 0.
  - required_members는 독립 계수 445개이며 missing 0.
  - fixture manifest의 8개 gzip 모두 gzip hash/raw decompressed hash/shape byte length 일치.
  - fixture manifest + 8 gzip은 Git c5971ea의 원 blob과 byte mismatch 0.
  - fixture distribution manifest가 기록한 wheel 내부 .so 19개를 wheel bytes에서 직접 다시 hash: missing 0, mismatch 0.
  - 이전 Gate 2C 등 preserve_prior_raw_files 67개는 현재 seal hash mismatch 0이며 Gate 2C.1 plan commit d87b06a의 동일 경로 blob과 byte difference 0.
  - git bundle verify: complete history, HEAD bb436647ee76a0bd73dfd108f4db8d295a17d61f. fresh clone clean.
  - bundle 자체를 제외한 manifest 644개 파일이 fresh clone HEAD의 bytes와 모두 일치.
독립 검증 방법:
  - ZIP을 직접 읽어 SHA-256/CRC/member set/hash 전수 검사.
  - wheel을 다시 ZIP으로 열어 내부 19개 .so hash 재계산.
  - git bundle verify + fresh clone + git show c5971ea:path + HEAD byte comparison.
재현 명령 또는 checker:
  - sha256sum gate2c1-complete-audit-2026-10-02.zip
  - git bundle verify git/gate2c1.bundle
  - git clone git/gate2c1.bundle <fresh-dir>
발견된 문제: 없음 (외부 delivery sidecar 실물 부재는 아래 '추가 의무'에서 별도 UNRESOLVED)
```

## A4

```yaml
A4: PASS
근거:
  regular:
    V2 certified prefix: 100000
    first V2 REFUSED: null
    cross PASS prefix: 100000
    first cross REFUSED: null
    replay mismatches: 0
    raw enclosure violations: 0
  chaotic:
    V2 PASS through: 13906
    first V2 REFUSED: 13907
    cross PASS through: 13662
    first cross REFUSED: 13663
    replay mismatches: 0
    raw enclosure violations: 0
  - 기존 숫자를 expected answer로 넣지 않았다. frozen initial state부터 매 step 순차 전파하여 최초 거부를 탐색했다.
  - regular/chaotic 각각 100개 producer segment를 독립 endpoint와 비교: endpoint mismatch 0, decision digest mismatch 0, hash-chain/coverage error 0.
  - package의 separate-path independent segment 100개/Orbit도 producer와 full start/end/Forms/digest/coverage 값 mismatch 0.
  - 합계 400 segment 자료가 연결되며 reset/snap으로 시작하지 않는다.
  - first refusal 뒤 PASS 재등장: V2 0, cross 0.
독립 검증 방법:
  - initial zero error에서 100000 step을 연속 전파.
  - checkpoint는 계산 중 검증 대상으로만 읽고 다음 segment seed로 사용하지 않음.
재현 명령 또는 checker:
  - /mnt/data/gate2c1_audit_work/independent_audit.py
  - /mnt/data/gate2c1_audit_work/final_independent_results.json
발견된 문제: 없음
```

## A5

```yaml
A5: PASS
근거:
  - chaotic cross 최초 거부는 nonfinite/exception/replay/cost가 아니라 정확히 finite scale criterion이다.
  - step 13662: max(E+F)-scale = -0x58799efda8e1 * 2^-54 < 0 -> PASS.
  - step 13663: max(E+F)-scale = +0x63464e66207f * 2^-54 > 0 -> 최초 REFUSED.
  - cross reason range 13663..13734: sum bound >= represented state scale.
  - Lab bound는 13735에서 최초 nonfinite. 이후 cross는 bound unavailable/nonfinite로 fail-closed.
  - chaotic V2 최초 거부도 finite scale criterion이다.
  - step 13906: max(E)-scale = -0x323176875ab * 2^-50 < 0 -> PASS.
  - step 13907: max(E)-scale = +0x53dfed42dd1f * 2^-52 > 0 -> 최초 REFUSED.
  - V2 reason range 13907..13952: bound >= represented state scale.
  - binary latent bound는 13953에서 ArithmeticError: nonfinite latent bound. 이후 bound unavailable로 fail-closed.
  - replay mismatch 0, cost abort 없음.
독립 검증 방법:
  - boundary 전후 값을 binary64가 나타내는 정확한 dyadic Fraction으로 변환하고 bound/scale 차이 부호를 계산.
  - 1..100000 전체 상태에서 최초 거부와 이후 sticky prefix를 확인.
재현 명령 또는 checker:
  - /mnt/data/gate2c1_audit_work/horizon_only.py
  - /mnt/data/gate2c1_audit_work/horizon_only.json
발견된 문제: 없음
```

## A6

```yaml
A6: PASS
근거:
  exact identity:
    u_n = p_n - (h/2) g(q_n)
    q_(n+1) = q_n + h u_n
    p_(n+1) = u_n - (h/2) g(q_(n+1))
    u_(n+1) = u_n - h g(q_(n+1)) = p_(n+1) - (h/2) g(q_(n+1))
  - 따라서 T_bin의 exact staggered map과 Lab velocity-Verlet의 exact output은 같은 q_(n+1), p_(n+1)를 갖는다.
  - gradient도 exact arithmetic에서는 (x*y)+(x*y) = 2xy이므로 Lab exact target과 동일하다. machine rounding graph를 같다고 주장한 것이 아니라 exact target의 대수적 항등성만 사용했다.
  - triangle inequality |bin-lab| <= |bin-exact|+|lab-exact| <= E+F를 별도 유도.
  - regular 1..100000 및 chaotic 전체에서 E+F, residual, scale을 Fraction으로 계산.
  - regular cross 전 구간 PASS. chaotic raw enclosure violation 0.
  - residual > E+F가 존재할 경우 scale refusal보다 먼저 FAIL로 처리되는 경로를 코드 및 공격 시험으로 확인.
독립 검증 방법:
  - binary64 값을 정확한 dyadic Fraction으로 변환하여 residual과 E+F를 비교.
  - float로 변환한 값은 display에만 사용.
재현 명령 또는 checker:
  - /mnt/data/gate2c1_audit_work/independent_audit.py
발견된 문제: 없음
```

## A7

```yaml
A7: PASS
근거:
  - regular/chaotic 각각 n0=0,50000,99992, 총 6개 window를 검사.
  - frozen initial state에서 별도 binary replay로 각 n0까지 순차 전파하여 represented latent seed를 얻음. 저장된 producer start_latent와 6/6 모두 일치.
  - 각 window에서 local initial error만 zero로 두고, 8 step exact Fraction map을 독립 계산.
  - 총 48 step에서 output 4개와 internal latent 4개 모두 실제 binary64 error <= V2 enclosure.
  - violation 0.
  - 독립 계산한 exact_output, exact_internal, represented input, output/latent bits, output/internal bounds가 producer exact artifact와 6/6 전 기록 일치.
  - packaged worker-independent artifact와도 field normalization 뒤 6/6 전 기록 일치.
  - full vx/vy를 latent vh로 대체하지 않았다. seed는 x,y,vhx,vhy 그대로 사용.
  - 이 local zero reset을 global 100k 인증 근거로 사용하지 않았다.
독립 검증 방법:
  - exact truth는 Python Fraction numerator/denominator이며 고정밀 float를 사용하지 않음.
  - numerator/denominator는 16진 정수로 기록.
재현 명령 또는 checker:
  - /mnt/data/gate2c1_audit_work/exact_window_independent.py
  - /mnt/data/gate2c1_audit_work/exact_window_independent_results.json
발견된 문제: 없음
```

## A8

```yaml
A8: PASS
근거:
  - output bound가 None / negative / +inf / NaN / 길이 오류이면 REFUSED.
  - bound == represented-state scale인 equality case도 REFUSED.
  - cross raw residual violation은 scale이 커도 FAIL이며 REFUSED로 숨지 않음.
  - old opcode graph/상수/order/intermediate mutation은 sealed structure mismatch로 검출.
  - VM halt는 BinaryReplay._run에서 RuntimeError, runner는 EXECUTION abort로 fail-closed.
  - init rebase nonfinite는 ArithmeticError이고 forms가 usable state가 되지 않는다.
  - binary step rebase nonfinite는 forms=None + bin_dead, 이후 step에서 V2 forms 재사용 없음.
  - Lab nonfinite Forms는 snapshot에는 보존되지만 lab_dead 이후 propagation에 재사용되지 않는다.
  - huge Fraction display overflow는 display_float=None일 뿐 exact rational verdict에는 영향 없음.
  - deadline 도달은 loop abort + incomplete run으로 최종 PASS 불가.
  - 늦은 fixture replay mismatch는 replay_first가 sticky여서 이후 V2/cross를 REFUSED 처리하고 certified prefix를 되살리지 않음.
  - 독립 전체 전파에서도 최초 거부 뒤 PASS 재등장 0.
독립 검증 방법:
  - 별도 in-memory mutation/invalid-input 공격 및 runner control-flow 검토.
  - 직접 공격 결과: old_graph/constant/order/intermediate 모두 DETECTED; None/negative/inf/nan/equality 모두 REFUSED; raw violation은 FAIL.
재현 명령 또는 checker:
  - tests/test_gate2c1.py
  - tests/test_gate2c1_review_regressions.py
  - 별도 direct mutation script(감사 실행 기록)
발견된 문제: 없음
```

## A9

```yaml
A9: PASS
근거:
  - 별도 test copy에서 전체 suite 직접 실행: 250 passed in 21.51s.
  - init fail-stop/prefix zero, huge finite display overflow, pre/post seal failure result preservation, init rebase nonfinite 회귀시험이 실제 suite에 존재하고 실행됨.
  - malformed exact evidence(record missing/extra/bound/input), trace address/occurrence/ordinal/forms mutation, incomplete coverage, raw violation, replay mismatch, internal manifest 5종 mutation, missing wheel/.so, changed bundle, wrong external receipt/hash/filename에 대한 regression이 존재하고 통과.
  - Git chronology: d87b06a plan -> eb2305c method/cost -> 0f2fc62 implementation/producer -> 5504237 hardening -> c4f8d62 charter/code/delivery seal -> bb43664 frozen result.
  - c4f8d62(code-seal/delivery) 이후 bb43664까지 .py source diff 0.
  - V2 lab/v2_bound.py는 Gate 2C.1 base aa192ae부터 HEAD까지 diff 0.
  - producer 결과 뒤 worker independent checker의 hardening은 5504237에서 있었으나 code seal 전에 완료되었고, 이번 최종 판정은 해당 checker를 정답으로 사용하지 않고 별도 감사자 checker로 재계산했다.
독립 검증 방법:
  - fresh clone에서 pytest -q.
  - git diff / merge-base / commit ancestry / code-seal hash 검증.
재현 명령 또는 checker:
  - PYTHONPATH=<fresh-copy> python -m pytest -q
  - git diff c4f8d62..bb43664 -- '*.py'
발견된 문제: 없음
```

## A10

```yaml
A10: PASS
근거:
  - run/report는 gala replay equality를 KNOWN_PREREQUISITE_NOT_BLIND_SUCCESS / post-diagnostic knowledge로 명시.
  - 기존 chaotic horizon 숫자의 재일치를 성공 조건으로 쓰는 코드/charter 조건을 찾지 못함.
  - 이번 감사자는 기존 13662/13663/13906/13907을 checker expected value로 넣지 않고 최초 refusal을 순차 탐색했으며 결과가 독립적으로 동일해졌다.
독립 검증 방법:
  - report/runner/charter의 label과 verdict path 검토 + 독립 최초 거부 탐색.
재현 명령 또는 checker:
  - grep KNOWN_PREREQUISITE_NOT_BLIND_SUCCESS run_gate2c1.py reports/.../gate2c1_report.json
  - /mnt/data/gate2c1_audit_work/independent_audit.py
발견된 문제: 없음
```

## A11

```yaml
A11: PASS
근거:
  - docs/GATE2C1_RESULT.md는 연속 Hénon–Heiles 궤적, method error, gala 전체, 다른 플랫폼/분기, 새 Linux wheel 실행을 인증하지 않는다고 명시.
  - run report certification_scope는 roundoff layer of same exact discrete map only.
  - 실제 증거도 특정 frozen wheel/branch/input의 machine execution과 동일 exact discrete map 사이의 rounding layer만 다룬다.
독립 검증 방법:
  - charter/result/runner scope 문구와 실제 checker 입력 범위를 대조.
재현 명령 또는 checker:
  - grep certification_scope run_gate2c1.py reports/.../gate2c1_report.json
발견된 문제: 없음
```

---

## 추가 연결·provenance 의무

```yaml
추가_연결_provenance: UNRESOLVED
근거:
  PASS:
    - 각 1000-step segment start/end full center/Forms 연결 독립 비교 완료.
    - regular 100 + chaotic 100 producer segment endpoint mismatch 0.
    - decision digest mismatch 0, coverage/hash-chain error 0.
    - packaged separate-path segment 200개도 producer segment와 full start/end/Forms/digest/coverage mismatch 0.
    - 총 400 segment 자료의 연결이 확인됨.
    - zero reset/saved checkpoint를 global seed로 사용하지 않았음.
    - 방법 seal은 horizon 측정 전에 commit됨(gate2c1_horizon_or_cross_measured=false).
    - cost_survey는 method seal에 포함되고 plan -> method -> implementation -> result Git 순서가 실제 ancestry로 확인됨.
    - frozen V2 source는 base부터 HEAD까지 변경 없음.
    - ZIP actual SHA와 사용자 메시지에 제공된 claimed SHA는 정확히 일치.
    - internal manifest 645/required 445/member hashes/bundle/wheel/.so provenance는 전부 독립 확인됨.
  UNRESOLVED:
    - Charter가 요구하는 ZIP 외부 DELIVERY.md, delivery_receipt.json, gate2c1-complete-audit-2026-10-02.zip.sha256의 실제 bytes가 이번 전달에 포함/첨부되지 않았다.
    - 따라서 '최종 ZIP을 닫은 뒤 생성된 세 외부 문서가 실제로 동일 filename/hash를 가리켰다'는 역사적 delivery fact는 독립 확인 불가.
    - package verifier 코드와 mutation regression은 이 불일치를 검출하도록 되어 있고 테스트도 통과했지만, 그것은 실제 외부 3개 파일의 존재/내용을 대신하지 못한다.
재현 명령 또는 checker:
  - ZIP 내부 및 전달 attachment set에서 DELIVERY.md / delivery_receipt.json / gate2c1-complete-audit-2026-10-02.zip.sha256 검색 -> 없음.
  - actual ZIP hash: b3adbc940d7c819a87f2366bb36c10a0e67597976bb9b85f3c50503ef85c261d.
발견된 문제:
  - 증거 부재에 따른 UNRESOLVED 1건. 수치 under-bound/false PASS 반례는 아님.
```

---

## Severity 집계

```makefile
Critical: 0
Major: 0
Minor: 0
UNRESOLVED: 1
```

UNRESOLVED 1건은 수치 soundness의 반례가 아니라 **외부 delivery provenance 증거 부재**다. 그러나 charter의 최종 PASS 규칙은 `UNRESOLVED 0`을 명시하므로 무시하거나 Minor로 낮출 수 없다.

## 최종 판정

```text
Gate 2C.1 independent audit:
CONDITIONAL
```

A1–A11은 모두 PASS이며, 현재 확인된 유일한 closure blocker는 외부 delivery triplet의 실물 검증이다. 따라서 현재 전달 bytes만으로 Gate 2C 계열을 `CLOSED / PASS`로 승격하면 charter 위반이다.
