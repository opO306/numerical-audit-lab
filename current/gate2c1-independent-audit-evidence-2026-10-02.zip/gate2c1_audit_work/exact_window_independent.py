import importlib.util,json,math,hashlib
from pathlib import Path
from fractions import Fraction as Q
spec=importlib.util.spec_from_file_location('ia','/mnt/data/gate2c1_audit_work/independent_audit.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
from lab.v2_bound import step_forms,rebase,zero_forms
P=Path('/mnt/data/gate2c1_audit_pkg')

def rat(q): return [hex(q.numerator),hex(q.denominator)]
def run_local(seed):
 st=tuple(seed); exact=tuple(m.bq(v) for v in st); forms=zero_forms(); recs=[];viol=[]
 for j in range(1,9):
  inp=st
  regs=m.execute(m.BIN_STEP,dict(zip(('x','y','vhx','vhy'),st)))
  fo=step_forms(m.BIN_STEP,regs,dict(zip(('x','y','vhx','vhy'),forms)))
  E=[fo[k].rad() for k in m.OUTPUT_BIN]; forms,IE=rebase([fo[k] for k in m.LAT])
  x,y,u,v=exact; xn=x+u/Q(64);yn=y+v/Q(64);gx=xn+2*xn*yn;gy=yn+xn*xn-yn*yn
  exout=(xn,yn,u-gx/Q(128),v-gy/Q(128)); exact=(xn,yn,u-gx/Q(64),v-gy/Q(64))
  out=[regs[k] for k in m.OUTPUT_BIN]; st=tuple(regs[k] for k in m.LAT)
  for i in range(4):
   if abs(m.bq(out[i])-exout[i])>Q(E[i]):viol.append([j,'output',i])
   if abs(m.bq(st[i])-exact[i])>Q(forms[i].rad()):viol.append([j,'internal',i])
  recs.append({'step':j,'represented_input_latent':[f'{v:016x}' for v in inp],
   'output':[f'{v:016x}' for v in out],'next_latent':[f'{v:016x}' for v in st],
   'exact_output':[rat(v) for v in exout],'exact_internal':[rat(v) for v in exact],
   'output_bounds':[v.hex() for v in E],'internal_bounds':[f.rad().hex() for f in forms]})
 return {'violations':viol,'records':recs}

ans={}
for orbit in ('regular','chaotic'):
 rows=m.load_fixture(orbit);initial=[rows[i][0] for i in range(4)]
 ir=m.execute(m.BIN_INIT,dict(zip(('x','y','vx','vy'),initial)));st=tuple(ir[k] for k in ('x','y','vhx','vhy'))
 seeds={0:st}; replay=[]
 for j in range(1,100001):
  regs=m.execute(m.BIN_STEP,dict(zip(('x','y','vhx','vhy'),st)))
  for c,k in enumerate(m.OUTPUT_BIN):
   if regs[k]!=rows[c][j] and len(replay)<20:replay.append([j,c,f'{regs[k]:016x}',f'{rows[c][j]:016x}'])
  st=tuple(regs[k] for k in m.LAT)
  if j in (50000,99992):seeds[j]=st
 od={'replay_mismatches':replay,'windows':{}}
 for n0 in (0,50000,99992):
  d=run_local(seeds[n0]); prod=json.load(open(P/f'reports/gate2c1-measured-2026-10-02/evidence/exact/{orbit}_{n0}_8step.json'))
  # strict compare against stored producer records, after independent calculation
  same_seed=prod['start_latent']==[f'{v:016x}' for v in seeds[n0]]
  same_records=d['records']==prod['records']
  indep=json.load(open(P/f'reports/gate2c1-independent-2026-10-02/exact/{orbit}_{n0}_8step.json'))
  norm=[]
  for r in indep['records']:
   norm.append({'step':r['step'],'represented_input_latent':r['input_latent'],'output':r['output'],'next_latent':r['internal'],
                'exact_output':r['exact_output'],'exact_internal':r['exact_internal'],'output_bounds':r['output_bounds'],'internal_bounds':r['internal_bounds']})
  od['windows'][str(n0)]={'seed':[f'{v:016x}' for v in seeds[n0]],'seed_matches_producer':same_seed,'records_match_producer':same_records,
      'records_match_packaged_independent':d['records']==norm,'violations':d['violations'],'records':d['records']}
 ans[orbit]=od
out=Path('/mnt/data/gate2c1_audit_work/exact_window_independent_results.json');out.write_text(json.dumps(ans,indent=2,sort_keys=True)+'\n')
print(json.dumps({o:{'replay':len(d['replay_mismatches']),'windows':{n:{k:v[k] for k in ('seed_matches_producer','records_match_producer','records_match_packaged_independent','violations')} for n,v in d['windows'].items()}} for o,d in ans.items()},indent=2))
