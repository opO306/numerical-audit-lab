from __future__ import annotations
import gzip, hashlib, json, math, struct, sys, time
from pathlib import Path
from fractions import Fraction as Q

ROOT=Path('/mnt/data/gate2c1_audit_pkg')
sys.path.insert(0,str(ROOT))
# Accepted audited/frozen V2 only. No Gate2C/Gate2C.1 evaluator/runner imports.
from lab.v2_bound import step_forms, rebase, zero_forms

SIGN=1<<63; FRAC=(1<<52)-1; MAX_FIN=0x7fefffffffffffff
OUTPUT_BIN=('x1','y1','vox','voy'); LAT=('x1','y1','vhx1','vhy1')
LAB_STATE=('x','y','px','py'); LAB_OUT=('x1','y1','px1','py1')

# Hand-transcribed only after independent .so/source inspection.
BIN_INIT=[
 ('CONST','dt',(),'1/64'),('CONST','half',(),'1/2'),('CONST','gz',(),'0'),
 ('MUL','xyi',('y','x'),None),('ADD','axi',('gz','x'),None),('MUL','xxi',('x','x'),None),
 ('ADD','dbli',('xyi','xyi'),None),('ADD','gxi',('dbli','axi'),None),('MUL','yyi',('y','y'),None),
 ('ADD','ayi',('y','gz'),None),('SUB','diffi',('xxi','yyi'),None),('ADD','gyi',('diffi','ayi'),None),
 ('MUL','hhalf',('dt','half'),None),('MUL','kx',('gxi','hhalf'),None),('SUB','vhx',('vx','kx'),None),
 ('MUL','ky',('gyi','hhalf'),None),('SUB','vhy',('vy','ky'),None)]
BIN_STEP=[
 ('CONST','dt',(),'1/64'),('CONST','half',(),'1/2'),('CONST','gz',(),'0'),
 ('MUL','dx',('dt','vhx'),None),('ADD','x1',('dx','x'),None),('MUL','dy',('dt','vhy'),None),('ADD','y1',('dy','y'),None),
 ('MUL','xys',('y1','x1'),None),('ADD','axs',('gz','x1'),None),('MUL','xxs',('x1','x1'),None),
 ('ADD','dbls',('xys','xys'),None),('ADD','gxs',('dbls','axs'),None),('MUL','yys',('y1','y1'),None),
 ('ADD','ays',('y1','gz'),None),('SUB','diffs',('xxs','yys'),None),('ADD','gys',('diffs','ays'),None),
 ('MUL','hhalf',('dt','half'),None),('MUL','kx',('gxs','hhalf'),None),('SUB','vox',('vhx','kx'),None),
 ('MUL','gdx',('dt','gxs'),None),('SUB','vhx1',('vhx','gdx'),None),
 ('MUL','ky',('gys','hhalf'),None),('SUB','voy',('vhy','ky'),None),
 ('MUL','gdy',('dt','gys'),None),('SUB','vhy1',('vhy','gdy'),None)]

LAB=[('CONST','h',(),'1/64'),('CONST','hh',(),'1/128'),('CONST','two',(),'2')]
def force(sx,sy,t):
 return [('MUL','xy'+t,(sx,sy),None),('MUL','txy'+t,('two','xy'+t),None),('NEG','nx'+t,(sx,),None),
         ('SUB','ax'+t,('nx'+t,'txy'+t),None),('MUL','xx'+t,(sx,sx),None),('MUL','yy'+t,(sy,sy),None),
         ('NEG','ny'+t,(sy,),None),('SUB','u'+t,('ny'+t,'xx'+t),None),('ADD','ay'+t,('u'+t,'yy'+t),None)]
LAB += force('x','y','0') + [
 ('MUL','kx',('hh','ax0'),None),('ADD','pxh',('px','kx'),None),('MUL','ky',('hh','ay0'),None),('ADD','pyh',('py','ky'),None),
 ('MUL','dx',('h','pxh'),None),('ADD','x1',('x','dx'),None),('MUL','dy',('h','pyh'),None),('ADD','y1',('y','dy'),None)]
LAB += force('x1','y1','1') + [
 ('MUL','kx1',('hh','ax1'),None),('ADD','px1',('pxh','kx1'),None),('MUL','ky1',('hh','ay1'),None),('ADD','py1',('pyh','ky1'),None)]


def bits_to_float(b): return struct.unpack('>d',struct.pack('>Q',b))[0]
def float_bits(x): return struct.unpack('>Q',struct.pack('>d',x))[0]
def bq(b):
 e=(b>>52)&0x7ff; f=b&FRAC; s=-1 if b&SIGN else 1
 if e==0x7ff: raise ValueError('nonfinite')
 if e==0:
  if f==0:return Q(0)
  return s*Q(f,1<<1074)
 m=(1<<52)|f
 shift=e-1023-52
 return s*(Q(m<<shift) if shift>=0 else Q(m,1<<(-shift)))

def round_even_int(n,d):
 q,r=divmod(n,d); t=r*2
 if t<d:return q
 if t>d:return q+1
 return q if q%2==0 else q+1

def floor_log2_pos(q:Q):
 n,d=q.numerator,q.denominator
 e=n.bit_length()-d.bit_length()
 if e>=0:
  if n < (d<<e): e-=1
 else:
  if (n<<(-e)) < d: e-=1
 return e

def round_q_bits(q:Q, zero_sign=0):
 if q==0:return SIGN if zero_sign else 0
 sign=SIGN if q<0 else 0; a=abs(q); e=floor_log2_pos(a)
 # overflow threshold for RN-even
 if a >= Q(2)**1024 - Q(2)**970: raise OverflowError('binary64 overflow')
 if e>=-1022:
  sh=52-e
  scaled=a*(1<<sh) if sh>=0 else a/Q(1<<(-sh))
  m=round_even_int(scaled.numerator,scaled.denominator)
  if m==(1<<53): e+=1; m=1<<52
  eb=e+1023
  return sign | (eb<<52) | (m-(1<<52))
 scaled=a*(1<<1074)
 m=round_even_int(scaled.numerator,scaled.denominator)
 if m==0:return sign
 if m==(1<<52):return sign | (1<<52)
 return sign | m

def zero_sign_for(op,a,b=None):
 # Only needed for exact-zero ADD/SUB. Use IEEE host operation solely to recover zero sign.
 fa=bits_to_float(a); fb=bits_to_float(b) if b is not None else 0.0
 z=fa+fb if op=='ADD' else fa-fb
 return 1 if float_bits(z)&SIGN else 0

def execute(structure, inputs):
 r=dict(inputs)
 for op,dst,args,lit in structure:
  if op=='CONST':
   r[dst]=round_q_bits(Q(lit))
  elif op=='NEG':
   r[dst]=r[args[0]]^SIGN
  else:
   a,b=r[args[0]],r[args[1]]; qa,qb=bq(a),bq(b)
   if op=='ADD': q=qa+qb
   elif op=='SUB': q=qa-qb
   elif op=='MUL': q=qa*qb
   else: raise ValueError(op)
   zs=zero_sign_for(op,a,b) if q==0 and op in ('ADD','SUB') else ((a>>63)^(b>>63) if q==0 and op=='MUL' else 0)
   r[dst]=round_q_bits(q,zs)
 return r

def load_fixture(orbit):
 p=ROOT/'benchmarks/gate2b/fixtures/cloud-2026-10-01'; m=json.load(open(p/'manifest.json'))['files'][orbit+'_forward']
 gz=(p/(orbit+'_forward.u64.gz')).read_bytes(); assert hashlib.sha256(gz).hexdigest()==m['sha256_gz']
 raw=gzip.decompress(gz); assert hashlib.sha256(raw).hexdigest()==m['sha256_raw']
 vals=struct.unpack('<%dQ'%(len(raw)//8),raw); rows,cols=m['shape']
 return [list(vals[i*cols:(i+1)*cols]) for i in range(rows)]

def form_bits(forms):
 if forms is None:return None
 return [{'coefficients':[f'{float_bits(v):016x}' for v in fm.coef],'box':f'{float_bits(fm.box):016x}'} for fm in forms]

def snap(step,st,lst,bf,lf,fh,fc,bd,ld):
 return {'step':step,'bin_state':[f'{v:016x}' for v in st], 'lab_state':[f'{lst[k]:016x}' for k in LAB_STATE],
         'bin_forms':form_bits(bf),'lab_forms':form_bits(lf),'first_bin':fh,'first_cross':fc,'bin_dead':bd,'lab_dead':ld}

def enc(d): return (json.dumps(d,sort_keys=True,ensure_ascii=False,allow_nan=False)+'\n').encode()

def maxscale(bits): return max(abs(bq(v)) for v in bits)

def local_exact(seed):
 st=tuple(seed); exact=tuple(bq(v) for v in st); forms=zero_forms(); violations=[]; records=[]
 for j in range(1,9):
  regs=execute(BIN_STEP,dict(zip(('x','y','vhx','vhy'),st)))
  fo=step_forms(BIN_STEP,regs,dict(zip(('x','y','vhx','vhy'),forms)))
  E=[fo[k].rad() for k in OUTPUT_BIN]; forms,IE=rebase([fo[k] for k in LAT])
  x,y,u,v=exact; xn=x+u/Q(64); yn=y+v/Q(64); gx=xn+2*xn*yn; gy=yn+xn*xn-yn*yn
  exact_out=(xn,yn,u-gx/Q(128),v-gy/Q(128)); exact=(xn,yn,u-gx/Q(64),v-gy/Q(64))
  a=[regs[k] for k in OUTPUT_BIN]; st=tuple(regs[k] for k in LAT)
  for i in range(4):
   if abs(bq(a[i])-exact_out[i])>Q(E[i]): violations.append((j,'out',i))
   if abs(bq(st[i])-exact[i])>Q(forms[i].rad()): violations.append((j,'internal',i))
  records.append({'step':j,'out_bits':[f'{v:016x}' for v in a], 'latent_bits':[f'{v:016x}' for v in st],
                  'out_err':[[hex(abs(bq(a[i])-exact_out[i]).numerator),hex(abs(bq(a[i])-exact_out[i]).denominator)] for i in range(4)],'out_bound':[E[i].hex() for i in range(4)],
                  'internal_err':[[hex(abs(bq(st[i])-exact[i]).numerator),hex(abs(bq(st[i])-exact[i]).denominator)] for i in range(4)],'internal_bound':[forms[i].rad().hex() for i in range(4)]})
 return {'violations':violations,'records':records}

def run_orbit(orbit,N=100000):
 rows=load_fixture(orbit); initial=[rows[i][0] for i in range(4)]
 ir=execute(BIN_INIT,dict(zip(('x','y','vx','vy'),initial)))
 fi=step_forms(BIN_INIT,ir,dict(zip(('x','y','vx','vy'),zero_forms())))
 bf,IE=rebase([fi[k] for k in ('x','y','vhx','vhy')])
 if any(not math.isfinite(v) or v<0 for v in IE): raise RuntimeError('init V2 failed')
 st=tuple(ir[k] for k in ('x','y','vhx','vhy')); lst=dict(zip(LAB_STATE,initial)); lf=zero_forms()
 fh=fc=bd=ld=None; raw=0; replay=[]; v2_after_refused_pass=[]; cross_after_refused_pass=[]
 counts={'PASS':0,'REFUSED':0,'FAIL':0}; windows={0:st}; boundary={}; segment_start=snap(0,st,lst,bf,lf,fh,fc,bd,ld); dh=hashlib.sha256(); prev_prod_hash=None
 segment_checks=0; endpoint_mismatch=[]; digest_mismatch=[]; independent_mismatch=[]; chain_errors=[]
 t0=time.time()
 for j in range(1,N+1):
  regs=execute(BIN_STEP,dict(zip(('x','y','vhx','vhy'),st))); a=[regs[k] for k in OUTPUT_BIN]
  for c,v in enumerate(a):
   if v!=rows[c][j] and len(replay)<10: replay.append((j,c,f'{v:016x}',f'{rows[c][j]:016x}'))
  lr=execute(LAB,lst); b=[lr[k] for k in LAB_OUT]
  E=F=None
  if bd is None:
   try:
    fo=step_forms(BIN_STEP,regs,dict(zip(('x','y','vhx','vhy'),bf))); E=[fo[k].rad() for k in OUTPUT_BIN]; nbf,IBE=rebase([fo[k] for k in LAT])
    if any(not math.isfinite(v) or v<0 for v in E+IBE) or any(not math.isfinite(x) for fm in nbf for x in fm.coef) or any((not math.isfinite(fm.box) or fm.box<0) for fm in nbf):
     bd={'step':j,'reason':'ArithmeticError: nonfinite latent bound'}; bf=None; E=None
    else: bf=nbf
   except Exception as e:
    bd={'step':j,'reason':f'{type(e).__name__}: {e}'}; bf=None; E=None
  if ld is None:
   try:
    lfo=step_forms(LAB,lr,dict(zip(LAB_STATE,lf))); F=[lfo[k].rad() for k in LAB_OUT]; nlf,ILE=rebase([lfo[k] for k in LAB_OUT])
    if any(not math.isfinite(v) or v<0 for v in F+ILE) or any(not math.isfinite(x) for fm in nlf for x in fm.coef) or any((not math.isfinite(fm.box) or fm.box<0) for fm in nlf):
     ld={'step':j,'reason':'nonfinite Lab bound'}; lf=nlf; F=None
    else: lf=nlf
   except Exception as e:
    ld={'step':j,'reason':f'{type(e).__name__}: {e}'}; lf=None; F=None
  valid=E is not None and len(E)==4 and all(math.isfinite(v) and v>=0 for v in E)
  vp='PASS' if valid and max(Q(v) for v in E)<maxscale(a) and not replay else 'REFUSED'
  if vp=='REFUSED' and fh is None:
   reason=bd['reason'] if bd and bd['step']==j else ('replay does not match frozen external execution' if replay else 'bound >= represented state scale' if valid else 'bound unavailable or nonfinite')
   fh={'step':j,'reason':reason}
  elif fh and vp=='PASS': v2_after_refused_pass.append(j)
  sums=res=None; cp='REFUSED'; cr='bound unavailable or nonfinite'
  if E is not None and F is not None and all(math.isfinite(v) and v>=0 for v in E+F):
   sums=[Q(x)+Q(y) for x,y in zip(E,F)]; res=[abs(bq(x)-bq(y)) for x,y in zip(a,b)]
   bad=[i for i in range(4) if res[i]>sums[i]]; raw+=len(bad)
   if bad: cp='FAIL'; cr='residual exceeds exact sum bound'
   elif max(sums)<max(maxscale(a),maxscale(b)):cp='PASS';cr='residual contained in exact sum bound'
   else:cr='sum bound >= represented state scale'
  if replay: cp='REFUSED';cr='external execution replay mismatch'
  counts[cp]+=1
  if cp=='REFUSED' and fc is None: fc={'step':j,'reason':cr}
  elif fc and cp=='PASS':cross_after_refused_pass.append(j)
  dh.update(enc({'step':j,'bin':a,'lab':b,'E':[v.hex() for v in E] if E else None,'F':[v.hex() for v in F] if F else None,'v2':vp,'cross':cp}))
  st=tuple(regs[k] for k in LAT); lst=dict(zip(LAB_STATE,b))
  if j in (50000,99992): windows[j]=st
  if j in (13662,13663,13664,13906,13907,13908,13735,13953):
   boundary[j]={'v2':vp,'cross':cp,'E':[v.hex() for v in E] if E else None,'F':[v.hex() for v in F] if F else None,
                'bin_scale':str(maxscale(a)),'cross_scale':str(max(maxscale(a),maxscale(b))),
                'sums':[str(v) for v in sums] if sums else None,'residual':[str(v) for v in res] if res else None,
                'bin_dead':bd,'lab_dead':ld,'out':[f'{v:016x}' for v in a]}
  if j%1000==0:
   end=snap(j,st,lst,bf,lf,fh,fc,bd,ld)
   pp=ROOT/f'reports/gate2c1-measured-2026-10-02/evidence/segments/{orbit}/{j:06d}.json'
   ip=ROOT/f'reports/gate2c1-independent-2026-10-02/segments/{orbit}/{j:06d}.json'
   pb=pp.read_bytes(); p=json.loads(pb); ii=json.loads(ip.read_bytes())
   ph=hashlib.sha256(pb).hexdigest()
   if p['start']!=segment_start or p['end']!=end: endpoint_mismatch.append(j)
   if p['decision_digest']!=dh.hexdigest(): digest_mismatch.append((j,p['decision_digest'],dh.hexdigest()))
   if p['coverage']!=[j-999,j] or p['previous_segment_sha256']!=prev_prod_hash: chain_errors.append(j)
   # direct value equality, not hash-only
   if ii['start']!=p['start'] or ii['end']!=p['end'] or ii['decision_digest']!=p['decision_digest'] or ii['coverage']!=p['coverage'] or ii.get('producer_segment_sha256')!=ph:
    independent_mismatch.append(j)
   prev_prod_hash=ph; segment_start=end; dh=hashlib.sha256(); segment_checks+=1
   if j%10000==0: print(f'{orbit} {j}/{N} first_v2={fh} first_cross={fc} bd={bd} ld={ld} wall={time.time()-t0:.1f}',flush=True)
 out={'orbit':orbit,'steps':N,'replay_mismatches':replay,'first_v2':fh,'v2_prefix':fh['step']-1 if fh else N,'first_cross':fc,
      'cross_prefix':fc['step']-1 if fc else N,'raw_violations':raw,'cross_counts':counts,'bin_dead':bd,'lab_dead':ld,
      'v2_pass_after_first_refusal':v2_after_refused_pass[:20],'cross_pass_after_first_refusal':cross_after_refused_pass[:20],
      'segment_checks':segment_checks,'segment_endpoint_mismatch':endpoint_mismatch,'segment_digest_mismatch':digest_mismatch,
      'segment_chain_errors':chain_errors,'independent_segment_mismatch':independent_mismatch,'boundary':boundary,'wall':time.time()-t0}
 out['local_exact']={str(n0):local_exact(windows[n0]) for n0 in (0,50000,99992)}
 return out

def main():
 ans={}
 for o in ('regular','chaotic'): ans[o]=run_orbit(o)
 Path('/mnt/data/gate2c1_audit_work/full_independent_results.json').write_text(json.dumps(ans,indent=2,sort_keys=True)+'\n')
 print('FINAL_SUMMARY')
 for o,d in ans.items():
  print(o,{k:d[k] for k in ['v2_prefix','first_v2','cross_prefix','first_cross','raw_violations','bin_dead','lab_dead','segment_checks','segment_endpoint_mismatch','segment_digest_mismatch','segment_chain_errors','independent_segment_mismatch','replay_mismatches','v2_pass_after_first_refusal','cross_pass_after_first_refusal']})
  print('local violations',{k:len(v['violations']) for k,v in d['local_exact'].items()})
if __name__=='__main__':main()
