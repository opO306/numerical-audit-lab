import importlib.util, math, sys, json
from fractions import Fraction as Q
spec=importlib.util.spec_from_file_location('ia','/mnt/data/gate2c1_audit_work/independent_audit.py'); m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
from lab.v2_bound import step_forms,rebase,zero_forms
rows=m.load_fixture('chaotic'); initial=[rows[i][0] for i in range(4)]
ir=m.execute(m.BIN_INIT,dict(zip(('x','y','vx','vy'),initial))); fi=step_forms(m.BIN_INIT,ir,dict(zip(('x','y','vx','vy'),zero_forms()))); bf,_=rebase([fi[k] for k in ('x','y','vhx','vhy')])
st=tuple(ir[k] for k in ('x','y','vhx','vhy')); lst=dict(zip(m.LAB_STATE,initial)); lf=zero_forms(); fh=fc=bd=ld=None; raw=0; ranges=[]; last={}; boundary={}
def rec(kind,j,reason):
 p=last.get(kind)
 if p and p['reason']==reason and p['end']==j-1:p['end']=j
 else:
  e={'kind':kind,'start':j,'end':j,'reason':reason};ranges.append(e);last[kind]=e
for j in range(1,15001):
 regs=m.execute(m.BIN_STEP,dict(zip(('x','y','vhx','vhy'),st))); a=[regs[k] for k in m.OUTPUT_BIN]
 lr=m.execute(m.LAB,lst); b=[lr[k] for k in m.LAB_OUT]
 E=F=None
 if bd is None:
  try:
   fo=step_forms(m.BIN_STEP,regs,dict(zip(('x','y','vhx','vhy'),bf))); E=[fo[k].rad() for k in m.OUTPUT_BIN]; nbf,IBE=rebase([fo[k] for k in m.LAT])
   if any(not math.isfinite(v) or v<0 for v in E+IBE) or any(not math.isfinite(x) for fm in nbf for x in fm.coef) or any((not math.isfinite(fm.box) or fm.box<0) for fm in nbf):
    bd={'step':j,'reason':'ArithmeticError: nonfinite latent bound'};bf=None;E=None
   else:bf=nbf
  except Exception as e:bd={'step':j,'reason':f'{type(e).__name__}: {e}'};bf=None;E=None
 if ld is None:
  try:
   lfo=step_forms(m.LAB,lr,dict(zip(m.LAB_STATE,lf))); F=[lfo[k].rad() for k in m.LAB_OUT];nlf,ILE=rebase([lfo[k] for k in m.LAB_OUT])
   if any(not math.isfinite(v) or v<0 for v in F+ILE) or any(not math.isfinite(x) for fm in nlf for x in fm.coef) or any((not math.isfinite(fm.box) or fm.box<0) for fm in nlf):ld={'step':j,'reason':'nonfinite Lab bound'};lf=None;F=None
   else:lf=nlf
  except Exception as e:ld={'step':j,'reason':f'{type(e).__name__}: {e}'};lf=None;F=None
 valid=E is not None and all(math.isfinite(v) and v>=0 for v in E)
 scale=m.maxscale(a); vp='PASS' if valid and max(Q(v) for v in E)<scale else 'REFUSED'; reason='bound >= represented state scale' if valid else (bd['reason'] if bd and bd['step']==j else 'bound unavailable or nonfinite')
 if vp=='REFUSED':rec('V2',j,reason);fh=fh or {'step':j,'reason':reason}
 sums=res=None;cp='REFUSED';cr='bound unavailable or nonfinite'
 if E is not None and F is not None and all(math.isfinite(v) and v>=0 for v in E+F):
  sums=[Q(x)+Q(y) for x,y in zip(E,F)];res=[abs(m.bq(x)-m.bq(y)) for x,y in zip(a,b)];bad=[i for i in range(4) if res[i]>sums[i]];raw+=len(bad)
  cscale=max(m.maxscale(a),m.maxscale(b))
  if bad:cp='FAIL';cr='residual exceeds exact sum bound'
  elif max(sums)<cscale:cp='PASS';cr='residual contained in exact sum bound'
  else:cr='sum bound >= represented state scale'
 if cp=='REFUSED':rec('CROSS',j,cr);fc=fc or {'step':j,'reason':cr}
 if j in [13661,13662,13663,13664,13734,13735,13736,13905,13906,13907,13908,13952,13953,13954]:
  def qr(q): return [hex(q.numerator),hex(q.denominator)]
  boundary[str(j)]={'v2':vp,'cross':cp,'E':[v.hex() for v in E] if E else None,'F':[v.hex() for v in F] if F else None,'scale':qr(scale),'cross_scale':qr(max(m.maxscale(a),m.maxscale(b))),'maxE':qr(max(map(Q,E))) if E else None,'maxSum':qr(max(sums)) if sums else None,'residualMax':qr(max(res)) if res else None,'bd':bd,'ld':ld}
 st=tuple(regs[k] for k in m.LAT);lst=dict(zip(m.LAB_STATE,b))
print(json.dumps({'first_v2':fh,'first_cross':fc,'raw':raw,'bin_dead':bd,'lab_dead':ld,'ranges':ranges,'boundary':boundary},indent=2))
