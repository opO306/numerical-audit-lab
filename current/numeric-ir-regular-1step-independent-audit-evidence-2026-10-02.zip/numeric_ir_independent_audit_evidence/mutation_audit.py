from __future__ import annotations
import json,hashlib,copy,subprocess,tempfile,shutil,os
from pathlib import Path
ROOT=Path('/mnt/data/numeric_ir_audit_work/snapshot')
BASE=ROOT/'runtime_trace/artifacts/attempt-05'
BASE_IR=ROOT/'runtime_trace/numeric_ir/artifacts/attempt-05/numeric_ir.json'
OUT=Path('/mnt/data/numeric_ir_audit_work/mutation_results.json')

def canonical(x): return json.dumps(x,sort_keys=True,separators=(',',':')).encode()
def repair_ir(ir):
    norm={'schema':ir['schema'],'operations':ir['operations'],'values':ir['values']}
    ir['source']['normalized_numeric_sha256']=hashlib.sha256(canonical(norm)).hexdigest()
def replace_vid(ir,old,new):
    for op in ir['operations']:
        for k in ('input0_value_id','input1_value_id','output_value_id'):
            if op[k]==old:op[k]=new
    for v in ir['values']:
        for s in v['source_slices']:
            if s['value_id']==old:s['value_id']=new

def run_checker(name,mutator):
    ir=json.loads(BASE_IR.read_text()); mutator(ir); repair_ir(ir)
    td=Path(tempfile.mkdtemp(prefix='nir-mut-check-'))
    ip=td/'ir.json'; rp=td/'report.json'; ip.write_text(json.dumps(ir,sort_keys=True,separators=(',',':'))+'\n')
    p=subprocess.run(['python','-m','runtime_trace.numeric_ir.checker','--ir',str(ip),'--source',str(BASE),'--report',str(rp),'--root',str(ROOT)],cwd=ROOT,text=True,capture_output=True)
    rep=json.loads(rp.read_text()) if rp.exists() else {'verdict':'NO_REPORT'}
    shutil.rmtree(td)
    return {'name':name,'surface':'checker','exit':p.returncode,'verdict':rep.get('verdict'),'reason':rep.get('reason'),'stdout':p.stdout[-500:],'stderr':p.stderr[-500:]}

def rehash_raw(rows,cap):
    chain='0'*64
    for i,r in enumerate(rows):
        r['seq']=i
        u={k:v for k,v in r.items() if k!='chain'}
        chain=hashlib.sha256(bytes.fromhex(chain)+canonical(u)).hexdigest(); r['chain']=chain
    stream=b''.join(canonical(r)+b'\n' for r in rows)
    cap['record_count']=len(rows); cap['trace_sha256']=hashlib.sha256(stream).hexdigest(); cap['final_chain']=chain
    from collections import Counter
    cap['opcode_histogram']=dict(Counter(r.get('opcode') for r in rows))
    cap['scalar_fp_count']=sum(r.get('kind') in {'ADD','SUB','MUL'} for r in rows)
    return stream

def run_translator(name,mutator,adjust_regions=None):
    td=Path(tempfile.mkdtemp(prefix='nir-mut-src-')); src=td/'src'; src.mkdir()
    cap=json.loads((BASE/'capture.json').read_text()); rows=[json.loads(x) for x in (BASE/'trace.jsonl').read_bytes().splitlines()]
    mutator(rows,cap)
    if adjust_regions: adjust_regions(rows,cap)
    stream=rehash_raw(rows,cap)
    (src/'trace.jsonl').write_bytes(stream); (src/'capture.json').write_text(json.dumps(cap,sort_keys=True,separators=(',',':'))+'\n')
    out=td/'out'
    p=subprocess.run(['python','-m','runtime_trace.numeric_ir.translator','--source',str(src),'--out',str(out),'--root',str(ROOT)],cwd=ROOT,text=True,capture_output=True)
    verdict='CONVERTED' if p.returncode==0 else 'REFUSED'
    reason=None
    if p.returncode!=0:
        try: reason=json.loads(p.stderr.strip().splitlines()[-1]).get('reason')
        except Exception: reason=p.stderr[-500:]
    res={'name':name,'surface':'translator','exit':p.returncode,'verdict':verdict,'reason':reason,'stdout':p.stdout[-500:],'stderr_tail':p.stderr[-500:]}
    shutil.rmtree(td)
    return res

# A9 raw fail-closed mutations
raw=[]

def unsupported(rows,cap):
    r=rows[104]; r['instruction']='divsd  %xmm0,%xmm2'; r['opcode']='divsd'; r['kind']='MUL'
raw.append(run_translator('unsupported-opcode',unsupported))

def missing(rows,cap):
    del rows[104]
    # preserve region coverage geometry after removal enough to get beyond simple metadata
    cap['regions'][0]['end_seq']-=1; cap['regions'][1]['start_seq']-=1; cap['regions'][1]['end_seq']-=1
raw.append(run_translator('missing-trace-record',missing))

def duplicate(rows,cap):
    rows.insert(105,copy.deepcopy(rows[104])); cap['regions'][0]['end_seq']+=1; cap['regions'][1]['start_seq']+=1; cap['regions'][1]['end_seq']+=1
raw.append(run_translator('duplicate-trace-record',duplicate))

def reorder(rows,cap): rows[104],rows[105]=rows[105],rows[104]
raw.append(run_translator('reordered-records',reorder))

def width(rows,cap): rows[104]['operands'][0]['width']=4; rows[104]['operands'][0]['raw_bits']='0x00000000'; rows[104]['operands'][0]['origins']=rows[104]['operands'][0]['origins'][:4]
raw.append(run_translator('arithmetic-width-mismatch',width))

def operandbits(rows,cap): rows[139]['operands'][0]['raw_bits']='0x3fd0000000000000'
raw.append(run_translator('operand-bits-mutation',operandbits))

def outputbits(rows,cap): rows[139]['result_bits']='0x3f70000000000000'
raw.append(run_translator('output-bits-mutation',outputbits))

def elfmut(rows,cap): rows[104]['elf_address']+=1
raw.append(run_translator('module-elf-address-mutation',elfmut))

# A9 checker fail-closed mutations
def val(ir,vid): return next(v for v in ir['values'] if v['value_id']==vid)
check=[]
check.append(run_checker('missing-producer', lambda ir: ir['values'].remove(val(ir,ir['operations'][0]['input0_value_id']))))

def ambiguous(ir):
    x=copy.deepcopy(val(ir,'v:r104:result')); x['value_id']='v:rogue:ambiguous'; ir['values'].append(x)
check.append(run_checker('ambiguous-producer',ambiguous))

def dangling(ir): val(ir,'v:r104:arithmetic-source-read')['source_slices'][0]['value_id']='v:does-not-exist'
check.append(run_checker('dangling-provenance-edge',dangling))

def cycle(ir):
    v=val(ir,'v:r60:copy'); s=v['source_slices'][0]; s['value_id']=v['value_id']; s['source_offset']=0; s['source_storage']=copy.deepcopy(v['storage'])
check.append(run_checker('cyclic-provenance',cycle))

def dupid(ir): ir['values'].append(copy.deepcopy(ir['values'][0]))
check.append(run_checker('duplicated-value-identity',dupid))

def invalid_boundary(ir):
    v=val(ir,'v:boundary:step:latent'); v['producer_kind']='LOAD_BITS'; v['source_slices']=[]
check.append(run_checker('invalid-boundary-root',invalid_boundary))

def malformed(ir): ir['operations'][0]['trace_sequence']=104.0
check.append(run_checker('malformed-type',malformed))

# extra checker cases corresponding to mutated IR module/width/bits if desired
check.append(run_checker('ir-module-sha-mutation', lambda ir: ir['operations'][0].__setitem__('module_sha256','0'*64)))
check.append(run_checker('ir-output-bits-mutation', lambda ir: (ir['operations'][9].__setitem__('output_raw_bits','0x3f70000000000000'), val(ir,ir['operations'][9]['output_value_id']).__setitem__('raw_bits','0x3f70000000000000'))))

# A10 NEW attacks, deliberately different from packaged 19
new=[]

def a10_merge_delete(ir):
    op=next(o for o in ir['operations'] if o['trace_sequence']==107)
    old=op['input1_value_id']; new_id=op['input0_value_id']; assert val(ir,old)['raw_bits']==val(ir,new_id)['raw_bits']
    replace_vid(ir,old,new_id); ir['values']=[v for v in ir['values'] if v['value_id']!=old]
new.append(run_checker('NEW1-equal-bit-read-full-merge-delete',a10_merge_delete))

def a10_swap_producers(ir):
    a=val(ir,'v:r104:result'); b=val(ir,'v:r106:result'); assert a['raw_bits']==b['raw_bits']; assert a['producer']['operation_kind']==b['producer']['operation_kind']
    a['producer'],b['producer']=copy.deepcopy(b['producer']),copy.deepcopy(a['producer'])
new.append(run_checker('NEW2-equal-bit-arithmetic-producer-swap',a10_swap_producers))

def a10_boundary_disguise(ir):
    v=val(ir,'v:boundary:step:q'); v['producer_kind']='ARITHMETIC_RESULT'; v['producer']={'role':'arithmetic_result','trace_sequence':223,'operand_index':1,'phase':'step','operation_kind':'MUL_BINARY64'}; v['source_slices']=[]
new.append(run_checker('NEW3-boundary-copy-disguised-as-arithmetic',a10_boundary_disguise))

def a10_compensated_slice(ir):
    # r60 is a 16-byte all-zero copy from v:r57:zero. Shift both ends by 8 and narrow to 8,
    # retaining equal bytes and internally consistent storage ranges while deleting provenance for the other lane.
    v=val(ir,'v:r60:copy'); s=v['source_slices'][0]; assert v['raw_bits']=='0x'+'00'*16
    s['source_offset']=8; s['destination_offset']=8; s['width']=8
    s['source_storage']['byte_offset']=8; s['source_storage']['width']=8
    s['destination_storage']['byte_offset']=8; s['destination_storage']['width']=8
new.append(run_checker('NEW4-compensated-source-destination-slice-shift',a10_compensated_slice))

def a10_global_id_permutation(ir):
    x='v:r104:result'; y='v:r106:result'; assert val(ir,x)['raw_bits']==val(ir,y)['raw_bits']
    tmp='v:tmp:swap'
    # globally permute IDs and all references so graph connectivity stays isomorphic
    replace_vid(ir,x,tmp); replace_vid(ir,y,x); replace_vid(ir,tmp,y)
    for v in ir['values']:
        if v['value_id']==x:v['value_id']=tmp
        elif v['value_id']==y:v['value_id']=x
    for v in ir['values']:
        if v['value_id']==tmp:v['value_id']=y
new.append(run_checker('NEW5-global-equal-bit-value-id-permutation',a10_global_id_permutation))

allres=raw+check+new
summary={'all_nonpass':all(r['verdict'] not in ('PASS','CONVERTED') for r in allres),'raw_refused':sum(r['verdict']=='REFUSED' for r in raw),'checker_failed':sum(r['verdict']=='FAIL' for r in check+new),'results':allres}
OUT.write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
print(json.dumps(summary,indent=2,sort_keys=True))
