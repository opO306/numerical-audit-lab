from __future__ import annotations
import json, hashlib, struct, re, sys
from pathlib import Path
from dataclasses import dataclass
from fractions import Fraction
from collections import Counter, defaultdict

ROOT=Path('/mnt/data/numeric_ir_audit_work/snapshot')

class AuditFail(Exception): pass

def req(c,m):
    if not c: raise AuditFail(m)

def raw(text,width):
    req(isinstance(text,str) and re.fullmatch(r'0x[0-9a-f]+',text) is not None, f'raw shape {text!r}')
    n=int(text,16)
    req(0 <= n < 1<<(8*width), f'raw range {text}/{width}')
    return n.to_bytes(width,'little')

def hx(data:bytes): return '0x'+int.from_bytes(data,'little').to_bytes(len(data),'little').hex()[::-1] if False else f"0x{int.from_bytes(data,'little'):0{2*len(data)}x}"

def canonical(x): return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()

# independent ELF64 little-endian parser
def elf_file_offset(image:bytes,vaddr:int,length:int):
    req(image[:4]==b'\x7fELF','not ELF')
    req(image[4]==2 and image[5]==1,'not ELF64 little-endian')
    phoff=struct.unpack_from('<Q',image,32)[0]
    phentsize=struct.unpack_from('<H',image,54)[0]
    phnum=struct.unpack_from('<H',image,56)[0]
    for i in range(phnum):
        p_type,p_flags,p_offset,p_vaddr,p_paddr,p_filesz,p_memsz,p_align=struct.unpack_from('<IIQQQQQQ',image,phoff+i*phentsize)
        if p_type==1 and p_vaddr <= vaddr and vaddr+length <= p_vaddr+p_filesz:
            return p_offset+(vaddr-p_vaddr)
    raise AuditFail(f'vaddr {vaddr:x} outside file backed LOAD')

def load_modules(root:Path):
    man=json.loads((root/'runtime_trace/frozen_binaries/manifest.json').read_text())
    req(man['schema']=='runtime-trace-frozen-binaries-v1','frozen manifest schema')
    out={}
    for digest,rel in man['modules'].items():
        p=(root/rel).resolve(); req(p.is_file(),f'module missing {digest}')
        data=p.read_bytes(); req(hashlib.sha256(data).hexdigest()==digest,f'module hash {digest}')
        out[digest]=(p,data)
    return out

# independent narrow decoder for the only audited numeric arithmetic forms.
ARITH_OPBYTE={0x58:('addsd','ADD_BINARY64'),0x59:('mulsd','MUL_BINARY64'),0x5c:('subsd','SUB_BINARY64')}
def decode_scalar_sse(bytehex:str):
    b=bytes.fromhex(bytehex); i=0; saw_f2=False; rex=0
    # permit ordinary legacy prefixes before REX; only F2 makes scalar-double arithmetic here
    while i<len(b) and b[i] in (0x66,0x67,0xf2,0xf3,0x2e,0x36,0x3e,0x26,0x64,0x65):
        if b[i]==0xf2: saw_f2=True
        i+=1
    if i<len(b) and 0x40 <= b[i] <= 0x4f:
        rex=b[i]; i+=1
    if not (saw_f2 and i+2 < len(b) and b[i]==0x0f and b[i+1] in ARITH_OPBYTE):
        return None
    opbyte=b[i+1]; modrm=b[i+2]
    mod=(modrm>>6)&3; reg=((modrm>>3)&7) + (8 if (rex&4) else 0); rm=(modrm&7)+(8 if (rex&1) else 0)
    opcode,kind=ARITH_OPBYTE[opbyte]
    return {'opcode':opcode,'kind':kind,'mod':mod,'dst':f'xmm{reg}','src_reg':f'xmm{rm}' if mod==3 else None}

GPR_ALIAS={
 'rax':'rax','eax':'rax','ax':'rax','al':'rax',
 'rbx':'rbx','ebx':'rbx','bx':'rbx','bl':'rbx',
 'rcx':'rcx','ecx':'rcx','cx':'rcx','cl':'rcx',
 'rdx':'rdx','edx':'rdx','dx':'rdx','dl':'rdx',
 'rsi':'rsi','esi':'rsi','si':'rsi','sil':'rsi',
 'rdi':'rdi','edi':'rdi','di':'rdi','dil':'rdi',
 'rbp':'rbp','ebp':'rbp','bp':'rbp','bpl':'rbp',
 'rsp':'rsp','esp':'rsp','sp':'rsp','spl':'rsp',
}
for n in range(8,16):
    GPR_ALIAS[f'r{n}']=f'r{n}'; GPR_ALIAS[f'r{n}d']=f'r{n}'; GPR_ALIAS[f'r{n}w']=f'r{n}'; GPR_ALIAS[f'r{n}b']=f'r{n}'

def canon_reg(name):
    m=re.fullmatch(r'(xmm|ymm|zmm)(\d+)',name)
    if m: return 'v'+m.group(2)
    req(name in GPR_ALIAS,f'unknown reg alias {name}')
    return GPR_ALIAS[name]

def reg_capacity(name):
    if name.startswith('xmm'): return 16
    if name.startswith('ymm'): return 32
    if name.startswith('zmm'): return 64
    return 8

def reg_raw(ctx,name,width):
    if name.startswith(('xmm','ymm','zmm')):
        text=ctx.get('xmm',{}).get(name,ctx.get('extra_vectors',{}).get(name))
        req(text is not None,f'missing vector {name}')
        return raw(text,reg_capacity(name))[:width]
    full=canon_reg(name)
    return raw(ctx['gpr'][full],8)[:width]

def op_keys(op):
    if op['kind']=='memory': return [('m',op['address']+i) for i in range(op['width'])]
    if op['kind']=='register':
        c=canon_reg(op['register']); return [('r',c,i) for i in range(op['width'])]
    return []

# exact binary64 arithmetic and RN-even rounding
def bits_fraction(bits:int):
    sign=-1 if bits>>63 else 1
    e=(bits>>52)&0x7ff; f=bits&((1<<52)-1)
    req(e!=0x7ff,'nonfinite')
    if e==0:
        if f==0: return Fraction(0)
        q=Fraction(f,1<<1074)
    else:
        m=(1<<52)|f
        shift=e-1023-52
        q=Fraction(m*(1<<shift),1) if shift>=0 else Fraction(m,1<<(-shift))
    return q if sign>0 else -q

def round_even(fr:Fraction):
    n=fr.numerator//fr.denominator
    r=fr-Fraction(n,1)
    h=Fraction(1,2)
    if r>h or (r==h and (n&1)): n+=1
    return n

def floor_log2_pos(q:Fraction):
    req(q>0,'log2 nonpositive')
    n=q.numerator; d=q.denominator
    e=n.bit_length()-d.bit_length()
    if e>=0:
        if Fraction(1<<e,1)>q: e-=1
    else:
        if Fraction(1,1<<(-e))>q: e-=1
    while True:
        lo=Fraction(1<<e,1) if e>=0 else Fraction(1,1<<(-e))
        hi=Fraction(1<<(e+1),1) if e+1>=0 else Fraction(1,1<<(-(e+1)))
        if lo<=q<hi:return e
        if q<lo:e-=1
        else:e+=1

def frac_to_bits(q:Fraction, zero_sign=0):
    if q==0: return zero_sign<<63
    sign=1 if q<0 else 0
    a=-q if q<0 else q
    e=floor_log2_pos(a)
    if e>1023: return (sign<<63)|(0x7ff<<52)
    if e>=-1022:
        scale=52-e
        scaled=a*(1<<scale) if scale>=0 else a/Fraction(1<<(-scale),1)
        m=round_even(scaled)
        if m==(1<<53):
            e+=1; m=1<<52
            if e>1023:return (sign<<63)|(0x7ff<<52)
        req((1<<52)<=m<(1<<53),'normal mantissa range')
        return (sign<<63)|((e+1023)<<52)|(m-(1<<52))
    m=round_even(a*(1<<1074))
    if m==0:return sign<<63
    if m>=(1<<52):
        req(m==(1<<52),'subnormal carry')
        return (sign<<63)|(1<<52)
    return (sign<<63)|m

def exact_op_bits(opcode,a_bits,b_bits):
    # a=destination pre (input0), b=source (input1)
    a=bits_fraction(a_bits); b=bits_fraction(b_bits)
    if opcode=='addsd': q=a+b
    elif opcode=='subsd': q=a-b
    elif opcode=='mulsd': q=a*b
    else: raise AuditFail(opcode)
    zero_sign=0
    if q==0:
        sa=a_bits>>63; sb=b_bits>>63
        if opcode=='mulsd': zero_sign=sa^sb
        elif opcode=='addsd': zero_sign=1 if a==0 and b==0 and sa and sb else 0
        elif opcode=='subsd': zero_sign=1 if a==0 and b==0 and sa and not sb else 0
    return frac_to_bits(q,zero_sign)

@dataclass(frozen=True)
class Ref:
    vid:str; off:int; tag:str

class Reconstruct:
    def __init__(self,root,capture,rows,modules):
        self.root=root; self.cap=capture; self.rows=rows; self.modules=modules
        self.state={}; self.values=[]; self.vmap={}; self.vbytes={}; self.ops=[]
        self.region=None; self.phase=''; self.entry_rsp=0; self.prior={}
        self.origin_mismatches=[]
    def emit(self,vid,pk,data,producer,storage,slices):
        req(vid not in self.vmap,f'duplicate expected value {vid}')
        v={'value_id':vid,'producer_kind':pk,'raw_bits':hx(data),'width':len(data),'producer':producer,'storage':storage,'source_slices':slices}
        self.values.append(v); self.vmap[vid]=v; self.vbytes[vid]=data; return v
    def bval(self,r): return self.vbytes[r.vid][r.off]
    def storage(self,row,op,oi):
        w=op['width']
        if op['kind']=='register': return {'space':'register','name':canon_reg(op['register']),'byte_offset':0,'width':w}
        if op['kind']=='memory':
            a=op['address']; end=a+w; hits=[]
            for n,b in self.region['pointers'].items():
                if a<b+16 and b<end:hits.append((n,b))
            req(len(hits)<=1,f'ambiguous boundary alias row {row["seq"]}')
            if hits:
                n,b=hits[0]; req(b<=a and end<=b+16,f'partial boundary overlap row {row["seq"]}')
                return {'space':'buffer','name':n,'byte_offset':a-b,'width':w}
            rel=a-self.entry_rsp
            if abs(rel)<=1<<20:return {'space':'stack','name':self.phase,'byte_offset':rel,'width':w}
            return {'space':'memory-occurrence','name':f'{self.phase}:r{row["seq"]}:o{oi}','byte_offset':0,'width':w}
        if op['kind']=='immediate': return {'space':'instruction','name':f'r{row["seq"]}:o{oi}','byte_offset':0,'width':w}
        if op['kind'] in ('code_address','control'): return {'space':'control','name':f'r{row["seq"]}:o{oi}','byte_offset':0,'width':w}
        raise AuditFail(f'unknown storage kind {op["kind"]}')
    def substorage(self,s,off,w): return {'space':s['space'],'name':s['name'],'byte_offset':s['byte_offset']+off,'width':w}
    def slices(self,refs,dst,seq,oi):
        out=[]; i=0
        while i<len(refs):
            r=refs[i]
            if r is None:i+=1;continue
            j=i+1
            while j<len(refs) and refs[j] is not None and refs[j].vid==r.vid and refs[j].off==r.off+(j-i):j+=1
            w=j-i; src=self.vmap[r.vid]['storage']
            out.append({'value_id':r.vid,'source_offset':r.off,'destination_offset':i,'width':w,'trace_sequence':seq,'source_operand_index':oi,'source_storage':self.substorage(src,r.off,w),'destination_storage':self.substorage(dst,i,w)})
            i=j
        return out
    def check_refs(self,row,op,refs):
        data=raw(op['raw_bits'],op['width']); origins=op.get('origins')
        req(isinstance(origins,list) and len(origins)==op['width'],f'origin shape row {row["seq"]}')
        for i,r in enumerate(refs):
            if r is None: continue
            req(self.bval(r)==data[i],f'known byte mismatch row {row["seq"]} byte {i}')
            req(origins[i]==r.tag,f'origin tag mismatch row {row["seq"]} byte {i}: raw={origins[i]} expected={r.tag}')
    def const_refs(self,row,op,oi):
        origin=op.get('constant_origin')
        if origin is None:
            if op['kind']=='immediate' and not any(raw(op['raw_bits'],op['width'])):
                vid=f'v:r{row["seq"]}:o{oi}:literal-zero'; st=self.storage(row,op,oi); data=bytes(op['width'])
                self.emit(vid,'ZERO_BITS',data,{'role':'instruction_zero','trace_sequence':row['seq'],'operand_index':oi,'phase':row['phase']},st,[])
                return [Ref(vid,i,'instruction_literal') for i in range(op['width'])]
            return None
        d=origin['module_sha256']; off=origin['file_offset']; req(d in self.modules,'constant module missing')
        image=self.modules[d][1]; data=raw(op['raw_bits'],op['width'])
        req(image[off:off+op['width']]==data,f'constant bytes mismatch row {row["seq"]}')
        exp=[f'ELF_CONST:{d}:{off+i}' for i in range(op['width'])]
        req(op.get('origins')==exp,f'constant origins mismatch row {row["seq"]}')
        vid=f'v:r{row["seq"]}:o{oi}:const'; st={'space':'elf','name':d,'byte_offset':off,'width':op['width']}
        self.emit(vid,'CONST_BITS',data,{'role':'constant_read','trace_sequence':row['seq'],'operand_index':oi,'phase':row['phase'],'module_sha256':d,'file_offset':off},st,[])
        return [Ref(vid,i,exp[i]) for i in range(op['width'])]
    def source_refs(self,row,op,oi):
        c=self.const_refs(row,op,oi)
        if c is not None:return c
        refs=[self.state.get(k) for k in op_keys(op)]; self.check_refs(row,op,refs); return refs
    def assign(self,op,vid,known,tag):
        keys=op_keys(op); ks=set(known)
        for i,k in enumerate(keys):
            if i in ks:self.state[k]=Ref(vid,i,tag)
            else:self.state.pop(k,None)
    def zero_piece(self,row,dst,role,offset,width,suffix):
        if width<=0:return
        base=self.storage(row,dst,len(row['operands'])-1); st=self.substorage(base,offset,width); vid=f'v:r{row["seq"]}:{role.replace("_","-")}'
        self.emit(vid,'ZERO_BITS',bytes(width),{'role':role,'trace_sequence':row['seq'],'operand_index':len(row['operands'])-1,'phase':row['phase']},st,[])
        keys=op_keys(dst)
        c=canon_reg(dst['register']) if dst['kind']=='register' else None
        for li in range(width):
            ki=offset+li
            k=keys[ki] if ki<len(keys) else ('r',c,ki)
            self.state[k]=Ref(vid,li,f'record:{row["seq"]}:{suffix}')
    def boundary(self,phase,name,data,prior=None):
        vid=f'v:boundary:{phase}:{name}'; isreg=name.startswith('xmm')
        st={'space':'register' if isreg else 'buffer','name':('v'+name[3:]) if isreg else name,'byte_offset':0,'width':len(data)}
        prod={'role':'boundary','phase':phase,'boundary':name,'trace_sequence':None,'operand_index':None}
        if prior is None: pk='LOAD_BITS'; slices=[]
        else:
            req(all(self.bval(r)==b for r,b in zip(prior,data)),f'boundary bits mismatch {phase} {name}')
            pk='COPY_BITS'; slices=self.slices(prior,st,None,None)
        self.emit(vid,pk,data,prod,st,slices)
        if isreg:
            tag=f'boundary:{phase}:{name}'
            for i in range(len(data)):self.state[('r',st['name'],i)]=Ref(vid,i,tag)
        else:
            base=self.region['pointers'][name]
            for i in range(len(data)):self.state[('m',base+i)]=Ref(vid,i,f'boundary:{phase}:{name}:{i}')
    def copy(self,row):
        src,dst=row['operands']; refs=self.source_refs(row,src,0)
        req(row['result_bits']==src['raw_bits'],f'copy result mismatch row {row["seq"]}')
        st=self.storage(row,dst,1); sl=self.slices(refs,st,row['seq'],0); keys=op_keys(dst)
        if sl:
            vid=f'v:r{row["seq"]}:copy'; data=raw(row['result_bits'],dst['width'])
            self.emit(vid,'COPY_BITS',data,{'role':'copy_result','trace_sequence':row['seq'],'operand_index':1,'phase':row['phase']},st,sl)
            self.assign(dst,vid,[i for i,r in enumerate(refs) if r is not None],f'record:{row["seq"]}')
        else:
            for k in keys:self.state.pop(k,None)
        # architectural 32-bit GPR zero extension for move/stack
        if dst['kind']=='register' and not dst['register'].startswith(('xmm','ymm','zmm')) and dst['width']==4:
            self.zero_piece(row,dst,'zero_extend',4,4,'zero_extend')
        if dst['kind']=='register' and dst['register'].startswith('xmm') and (row['opcode'] in {'movq','vmovd'} or (row['opcode']=='movsd' and src['kind']=='memory')):
            self.zero_piece(row,dst,'zero_upper',dst['width'],16-dst['width'],'zero_upper')
    def zero(self,row):
        dst=row['operands'][-1]; data=raw(row['result_bits'],dst['width']); req(not any(data),f'nonzero zero row {row["seq"]}')
        st=self.storage(row,dst,len(row['operands'])-1); vid=f'v:r{row["seq"]}:zero'
        self.emit(vid,'ZERO_BITS',data,{'role':'zero_result','trace_sequence':row['seq'],'operand_index':len(row['operands'])-1,'phase':row['phase']},st,[])
        self.assign(dst,vid,range(dst['width']),f'record:{row["seq"]}')
    def integer_zero(self,row):
        if row['opcode']!='xor' or len(row['operands'])!=2:return None
        a,d=row['operands']
        if not(a['kind']==d['kind']=='register' and a['register']==d['register']):return None
        w=d['width']; data=reg_raw(row['post'],d['register'],w); req(not any(data),f'integer zero bad row {row["seq"]}')
        st=self.storage(row,d,1); vid=f'v:r{row["seq"]}:integer-zero'
        self.emit(vid,'ZERO_BITS',data,{'role':'integer_zero','trace_sequence':row['seq'],'operand_index':1,'phase':row['phase']},st,[])
        c=canon_reg(d['register'])
        # conservative: 32-bit self-xor makes the upper bytes architecturally zero, but there is no separate IR value.
        # Clear them rather than retaining stale provenance.
        for i in range(8): self.state.pop(('r',c,i),None)
        for i in range(w): self.state[('r',c,i)]=Ref(vid,i,f'record:{row["seq"]}:integer_zero')
        return c
    def arith_input(self,row,oi,role):
        op=row['operands'][oi]
        refs=self.source_refs(row,op,oi); req(refs and all(r is not None for r in refs),f'unknown arithmetic provenance row {row["seq"]}')
        if op.get('constant_origin') is not None:return self.vmap[refs[0].vid]
        st=self.storage(row,op,oi); vid=f'v:r{row["seq"]}:{role.replace("_","-")}'
        return self.emit(vid,'COPY_BITS',raw(op['raw_bits'],8),{'role':role,'trace_sequence':row['seq'],'operand_index':oi,'phase':row['phase']},st,self.slices(refs,st,row['seq'],oi))
    def arithmetic(self,row,dec):
        src,dst=row['operands']; req(src['width']==dst['width']==8,'arith width')
        # independent operand role checks from ModRM encoding
        req(dst['kind']=='register' and dst['register']==dec['dst'],f'dest ModRM mismatch row {row["seq"]}')
        if dec['mod']==3:req(src['kind']=='register' and src['register']==dec['src_reg'],f'source ModRM mismatch row {row["seq"]}')
        else:req(src['kind']=='memory',f'memory source ModRM mismatch row {row["seq"]}')
        # pre state is the authoritative dynamic register value for register operands
        dst_pre=reg_raw(row['pre'],dst['register'],8); req(dst_pre==raw(dst['raw_bits'],8),f'dst pre raw mismatch row {row["seq"]}')
        if src['kind']=='register': req(reg_raw(row['pre'],src['register'],8)==raw(src['raw_bits'],8),f'src pre raw mismatch row {row["seq"]}')
        out=reg_raw(row['post'],dst['register'],8); req(out==raw(row['result_bits'],8),f'post result mismatch row {row["seq"]}')
        req(reg_raw(row['pre'],dst['register'],16)[8:]==reg_raw(row['post'],dst['register'],16)[8:],f'upper lane changed row {row["seq"]}')
        a=int.from_bytes(dst_pre,'little'); b=int(src['raw_bits'],16); expected=exact_op_bits(dec['opcode'],a,b)
        req(int.from_bytes(out,'little')==expected,f'exact RN-even mismatch row {row["seq"]}: got {int.from_bytes(out,"little"):016x} expected {expected:016x}')
        dval=self.arith_input(row,1,'arithmetic_destination_pre_read'); sval=self.arith_input(row,0,'arithmetic_source_read')
        st=self.storage(row,dst,1); vid=f'v:r{row["seq"]}:result'; kind=dec['kind']
        oval=self.emit(vid,'ARITHMETIC_RESULT',out,{'role':'arithmetic_result','trace_sequence':row['seq'],'operand_index':1,'phase':row['phase'],'operation_kind':kind},st,[])
        self.assign(dst,vid,range(8),f'record:{row["seq"]}')
        self.ops.append({'ir_sequence':len(self.ops),'trace_sequence':row['seq'],'module_sha256':row['module_sha256'],'elf_address':row['elf_address'],'instruction_bytes':row['bytes'],'opcode':dec['opcode'],'operation_kind':kind,'input0_value_id':dval['value_id'],'input1_value_id':sval['value_id'],'output_value_id':oval['value_id'],'input0_raw_bits':hx(dst_pre),'input1_raw_bits':src['raw_bits'],'output_raw_bits':hx(out),'mxcsr':row['pre']['mxcsr'],'phase':row['phase'],'step':row['step']})
    def invalidate(self,row,handled,integer_zero_reg=None):
        # clear changed GPRs that were not semantically handled
        for n,before in row['pre']['gpr'].items():
            if n=='rip':continue
            if before!=row['post']['gpr'][n] and not any(('r',n,i) in handled for i in range(8)) and n!=integer_zero_reg:
                for i in range(8):self.state.pop(('r',n,i),None)
        # independently avoid stale vector provenance on unclassified changes
        for xmm,before in row['pre'].get('xmm',{}).items():
            after=row['post'].get('xmm',{}).get(xmm)
            c=canon_reg(xmm)
            if after is not None and before!=after and not any(('r',c,i) in handled for i in range(16)):
                for i in range(16):self.state.pop(('r',c,i),None)
    def run(self):
        prior={}
        for ri,region in enumerate(self.cap['regions']):
            self.region=region; self.phase=region['phase']; self.entry_rsp=int(self.rows[region['start_seq']]['pre']['gpr']['rsp'],16); self.state={}
            for n in ('q','full_v','latent','gradient'):
                pr=prior.get(n) if ri==1 and n!='gradient' else None
                self.boundary(self.phase,n,raw(region['start_state'][n],16),pr)
            first=self.rows[region['start_seq']]
            for n in ('xmm0','xmm1'):self.boundary(self.phase,n,reg_raw(first['pre'],n,8),None)
            for row in self.rows[region['start_seq']:region['end_seq']]:
                dec=decode_scalar_sse(row['bytes']); handled=set(); iz=None
                if dec is not None:
                    self.arithmetic(row,dec); handled.update(op_keys(row['operands'][1]))
                elif row['kind'] in ('MOVE','STACK'):
                    self.copy(row); dst=row['operands'][1]; handled.update(op_keys(dst))
                    if dst['kind']=='register' and not dst['register'].startswith(('xmm','ymm','zmm')) and dst['width']==4:
                        c=canon_reg(dst['register']); handled.update(('r',c,i) for i in range(4,8))
                    if dst['kind']=='register' and dst['register'].startswith('xmm'):
                        c=canon_reg(dst['register']); handled.update(('r',c,i) for i in range(16))
                elif row['kind'] in ('ZERO','ZERO_FILL'):
                    self.zero(row); handled.update(op_keys(row['operands'][-1]))
                else:
                    iz=self.integer_zero(row)
                    if iz is not None: handled.update(op_keys(row['operands'][1]))
                self.invalidate(row,handled,iz)
            prior={}
            for n,base in region['pointers'].items():
                refs=[self.state.get(('m',base+i)) for i in range(16)]; req(all(r is not None for r in refs),f'endpoint unknown {self.phase} {n}')
                got=bytes(self.bval(r) for r in refs); req(got==raw(region['end_state'][n],16),f'endpoint bits {self.phase} {n}')
                prior[n]=refs
        return self.ops,self.values

def validate_source_and_elf(root,artifact,modules):
    d=root/'runtime_trace/artifacts'/artifact
    stream=(d/'trace.jsonl').read_bytes(); cap=json.loads((d/'capture.json').read_text()); rows=[json.loads(x) for x in stream.splitlines()]
    req(hashlib.sha256(stream).hexdigest()==cap['trace_sha256'],f'{artifact} trace sha')
    req(len(rows)==cap['record_count'],f'{artifact} count')
    req([r['seq'] for r in rows]==list(range(len(rows))),f'{artifact} seq')
    chain='0'*64
    for r in rows:
        unsigned={k:v for k,v in r.items() if k!='chain'}; chain=hashlib.sha256(bytes.fromhex(chain)+canonical(unsigned)).hexdigest(); req(r['chain']==chain,f'{artifact} chain row {r["seq"]}')
        req(r['module_sha256'] in modules,f'{artifact} unbundled module')
        image=modules[r['module_sha256']][1]; bb=bytes.fromhex(r['bytes']); off=elf_file_offset(image,r['elf_address'],len(bb))
        req(off==r['elf_file_offset'],f'{artifact} elf offset row {r["seq"]}')
        req(image[off:off+len(bb)]==bb,f'{artifact} instruction bytes row {r["seq"]}')
        req(r['runtime_pc']-r['module_load_base']==r['elf_address'],f'{artifact} PC/ELF row {r["seq"]}')
    req(chain==cap['final_chain'],f'{artifact} final chain')
    # derive arithmetic solely from encoding
    ars=[]
    for r in rows:
        dec=decode_scalar_sse(r['bytes'])
        if dec is not None: ars.append((r,dec))
    return cap,rows,stream,ars

def first_diff(a,b,path='$'):
    if type(a)!=type(b):return f'{path}: type {type(a).__name__}!={type(b).__name__}'
    if isinstance(a,dict):
        if set(a)!=set(b):return f'{path}: keys {sorted(set(a)^set(b))}'
        for k in a:
            d=first_diff(a[k],b[k],path+'.'+k)
            if d:return d
    elif isinstance(a,list):
        if len(a)!=len(b):return f'{path}: len {len(a)}!={len(b)}'
        for i,(x,y) in enumerate(zip(a,b)):
            d=first_diff(x,y,f'{path}[{i}]')
            if d:return d
    elif a!=b:return f'{path}: {a!r}!={b!r}'
    return None

def audit_artifact(root,artifact,modules):
    cap,rows,stream,ars=validate_source_and_elf(root,artifact,modules)
    rec=Reconstruct(root,cap,rows,modules); ops,vals=rec.run()
    ir=json.loads((root/'runtime_trace/numeric_ir/artifacts'/artifact/'numeric_ir.json').read_text())
    # independent metadata checks
    expected_regions=[{k:r[k] for k in ('phase','start_seq','end_seq','start_state','end_state','mxcsr')} for r in cap['regions']]
    source=ir['source']
    req(source['capture_schema']==cap['schema'],f'{artifact} source schema')
    req(source['trace_sha256']==hashlib.sha256(stream).hexdigest(),f'{artifact} source trace sha')
    req(source['final_chain']==cap['final_chain'],f'{artifact} source chain')
    req(source['record_count']==len(rows),f'{artifact} source record count')
    req(source['scalar_fp_count']==len(ars),f'{artifact} source arithmetic count')
    req(source['module_sha256s']==sorted({r['module_sha256'] for r in rows}),f'{artifact} module list')
    req(source['regions']==expected_regions,f'{artifact} regions')
    d1=first_diff(ir['operations'],ops); req(d1 is None,f'{artifact} operation mismatch {d1}')
    d2=first_diff(ir['values'],vals); req(d2 is None,f'{artifact} value mismatch {d2}')
    norm={'schema':ir['schema'],'operations':ir['operations'],'values':ir['values']}; nh=hashlib.sha256(canonical(norm)).hexdigest()
    req(source['normalized_numeric_sha256']==nh,f'{artifact} normalized hash field')
    return {'artifact':artifact,'record_count':len(rows),'arithmetic_count':len(ars),'arith_seqs':[r['seq'] for r,_ in ars],'op_hist':dict(Counter(d['opcode'] for _,d in ars)),'phase_hist':dict(Counter(r['phase'] for r,_ in ars)),'value_count':len(vals),'value_kinds':dict(Counter(v['producer_kind'] for v in vals)),'edge_count':sum(len(v['source_slices']) for v in vals),'normalized_sha256':nh,'ir_exact_match':True}

def main():
    modules=load_modules(ROOT)
    results=[]
    for a in ('attempt-05','closure-fresh-01'):
        results.append(audit_artifact(ROOT,a,modules))
    a=json.loads((ROOT/'runtime_trace/numeric_ir/artifacts/attempt-05/numeric_ir.json').read_text())
    b=json.loads((ROOT/'runtime_trace/numeric_ir/artifacts/closure-fresh-01/numeric_ir.json').read_text())
    na={'schema':a['schema'],'operations':a['operations'],'values':a['values']}; nb={'schema':b['schema'],'operations':b['operations'],'values':b['values']}
    req(canonical(na)==canonical(nb),'old/fresh normalized mismatch')
    # identity diagnostics
    ids=[v['value_id'] for v in a['values']]; req(len(ids)==len(set(ids)),'duplicate value ids')
    prodkeys=[]
    for v in a['values']:
        p=v['producer']; prodkeys.append((p.get('role'),p.get('phase'),p.get('trace_sequence'),p.get('operand_index'),p.get('boundary'),p.get('module_sha256'),p.get('file_offset')))
    req(len(prodkeys)==len(set(prodkeys)),'duplicate producer identity tuples')
    groups=defaultdict(list)
    for v in a['values']:groups[(v['width'],v['raw_bits'])].append(v['value_id'])
    equal_groups={f'{k[0]}:{k[1]}':v for k,v in groups.items() if len(v)>1}
    out={'verdict':'PASS','artifacts':results,'old_fresh_exact_normalized':True,'normalized_sha256':results[0]['normalized_sha256'],'equal_bit_groups':len(equal_groups),'largest_equal_bit_group':max(map(len,equal_groups.values())) if equal_groups else 0,'distinct_value_ids':len(ids)}
    print(json.dumps(out,indent=2,sort_keys=True))
    Path('/mnt/data/numeric_ir_audit_work/independent_reconstruction_report.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')

if __name__=='__main__':
    try:main()
    except Exception as e:
        print(type(e).__name__,e,file=sys.stderr); raise
