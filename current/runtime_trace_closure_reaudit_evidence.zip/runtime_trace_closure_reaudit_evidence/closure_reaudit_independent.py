import json, pathlib, hashlib, struct, subprocess, re, collections, sys
ROOT=pathlib.Path('/tmp/rt_closure/snapshot')
ART=ROOT/'runtime_trace/artifacts'
MODULE_PATHS=[
 ROOT/'runtime_trace/frozen_binaries/libc.so.6',
 ROOT/'audit/gate2c1/vendor/gala/integrate/cyintegrators/leapfrog.cpython-312-x86_64-linux-gnu.so',
 ROOT/'audit/gate2c1/vendor/gala/potential/potential/builtin/cybuiltin.cpython-312-x86_64-linux-gnu.so',
]

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
BIN_BY_SHA={sha(p):p for p in MODULE_PATHS}

def elf_loads(data):
    assert data[:4]==b'\x7fELF' and data[4]==2 and data[5]==1
    machine=struct.unpack_from('<H',data,18)[0]
    assert machine==62
    phoff=struct.unpack_from('<Q',data,32)[0]
    phentsize=struct.unpack_from('<H',data,54)[0]
    phnum=struct.unpack_from('<H',data,56)[0]
    out=[]
    for i in range(phnum):
        p_type,p_flags,p_off,p_va,p_pa,p_filesz,p_memsz,p_align=struct.unpack_from('<IIQQQQQQ',data,phoff+i*phentsize)
        if p_type==1:
            out.append(dict(flags=p_flags,off=p_off,va=p_va,filesz=p_filesz,memsz=p_memsz,align=p_align))
    return out

def fileoff(loads, va, n):
    for s in loads:
        if s['va'] <= va and va+n <= s['va']+s['filesz']:
            return s['off']+(va-s['va']), s
    raise AssertionError(('no PT_LOAD',hex(va),n))

def parse_objdump(path, start, stop):
    cmd=['objdump','-d','-M','att','--insn-width=16',f'--start-address={start}',f'--stop-address={stop}',str(path)]
    text=subprocess.check_output(cmd,text=True,stderr=subprocess.STDOUT)
    out={}
    pat=re.compile(r'^\s*([0-9a-fA-F]+):\s*((?:[0-9a-fA-F]{2}\s+)+)\s*(.*?)\s*$')
    for line in text.splitlines():
        m=pat.match(line)
        if not m: continue
        addr=int(m.group(1),16)
        b=bytes(int(x,16) for x in m.group(2).split())
        asm=m.group(3)
        out[addr]=(b,asm)
    return out

PREFIX={'data16','data32','cs','ds','es','ss','fs','gs','rep','repz','repnz','lock','bnd'}
def mnemonic(asm):
    # remove comments; retain symbol annotations harmlessly after operand
    ws=asm.split()
    i=0
    while i<len(ws) and (ws[i] in PREFIX or ws[i].startswith('rex')): i+=1
    return ws[i] if i<len(ws) else ''

def normop(op):
    return {'retq':'ret','callq':'call','jmpq':'jmp'}.get(op,op)

def read_rows(name):
    d=ART/name
    stream=(d/'trace.jsonl').read_bytes()
    rows=[json.loads(x) for x in stream.splitlines() if x.strip()]
    cap=json.load(open(d/'capture.json'))
    return d,stream,rows,cap

def verify_capture(name):
    d,stream,rows,cap=read_rows(name)
    errors=[]
    def req(c,msg):
        if not c: errors.append(msg)
    req(hashlib.sha256(stream).hexdigest()==cap['trace_sha256'],'trace sha')
    req(len(rows)==cap['record_count'],'record count')
    req([r['seq'] for r in rows]==list(range(len(rows))),'seq continuity')
    # independent chain
    chain='0'*64
    for r in rows:
        u={k:v for k,v in r.items() if k!='chain'}
        chain=hashlib.sha256(bytes.fromhex(chain)+json.dumps(u,sort_keys=True,separators=(',',':')).encode()).hexdigest()
        req(chain==r['chain'],f'chain seq {r["seq"]}')
    req(chain==cap['final_chain'],'final chain')
    # regions and dynamic linkage
    cursor=0
    for reg in cap['regions']:
        req(reg['start_seq']==cursor,f'region start {reg["phase"]}')
        sub=rows[reg['start_seq']:reg['end_seq']]
        req(bool(sub),f'nonempty {reg["phase"]}')
        if sub:
            req(sub[0]['runtime_pc']==reg['entry_pc'],f'entry {reg["phase"]}')
            req(sub[-1]['post_pc']==reg['return_pc'],f'return {reg["phase"]}')
        for i,r in enumerate(sub):
            req(r['phase']==reg['phase'],f'phase seq {r["seq"]}')
            req(r['runtime_pc']==int(r['pre']['gpr']['rip'],16),f'pre rip {r["seq"]}')
            req(r['post_pc']==int(r['post']['gpr']['rip'],16),f'post rip {r["seq"]}')
            if i:
                p=sub[i-1]
                req(p['post_pc']==r['runtime_pc'],f'pc linkage {r["seq"]}')
                for field in ('gpr','xmm','extra_vectors','mxcsr','eflags'):
                    req(p['post'][field]==r['pre'][field],f'{field} linkage {r["seq"]}')
        cursor=reg['end_seq']
    req(cursor==len(rows),'region total coverage')
    # decode ranges by module hash
    by=collections.defaultdict(list)
    for r in rows: by[r['module_sha256']].append(r)
    decoded={}
    bind_count=0
    module_counts={}
    for digest,rs in by.items():
        module_counts[digest]=len(rs)
        req(digest in BIN_BY_SHA,f'unexpected/unpackaged digest {digest}')
        if digest not in BIN_BY_SHA: continue
        p=BIN_BY_SHA[digest]; data=p.read_bytes(); loads=elf_loads(data)
        dec=parse_objdump(p,min(r['elf_address'] for r in rs),max(r['elf_address']+len(bytes.fromhex(r['bytes'])) for r in rs)+1)
        for r in rs:
            bb=bytes.fromhex(r['bytes'])
            req(r['module_load_base']+r['elf_address']==r['runtime_pc'],f'loadbase seq {r["seq"]}')
            off,seg=fileoff(loads,r['elf_address'],len(bb))
            req(off==r['elf_file_offset'],f'fileoff seq {r["seq"]}: {off}!={r["elf_file_offset"]}')
            req(data[off:off+len(bb)]==bb,f'ELF bytes seq {r["seq"]}')
            # independently compare mapping relation to actual PT_LOAD, not capture segments
            mp=r['mapping']
            req(mp['start']<=r['runtime_pc']<mp['end'] and 'x' in mp['perms'],f'exec mapping seq {r["seq"]}')
            page=4096
            req(mp['file_offset']==(seg['off']//page)*page,f'map file page seq {r["seq"]}')
            req(mp['start']==r['module_load_base']+(seg['va']//page)*page,f'map runtime page seq {r["seq"]}')
            req(bool(seg['flags']&1),f'PT_LOAD executable seq {r["seq"]}')
            req(r['elf_address'] in dec,f'decode missing seq {r["seq"]}')
            if r['elf_address'] in dec:
                db,asm=dec[r['elf_address']]
                req(db==bb,f'objdump bytes seq {r["seq"]}')
                mn=normop(mnemonic(asm)); rop=normop(r['opcode'])
                req(mn==rop,f'opcode decode seq {r["seq"]}: {mn} != {rop}; {asm}')
                decoded[r['seq']]=(mn,asm)
            bind_count += 1
    # scalar completeness from independent objdump mnemonics
    scalar=[]; unsupported=[]
    fp_pat=re.compile(r'^(?:v)?(?:add|sub|mul|div|max|min|sqrt).*(?:sd|ss|pd|ps)$')
    fma_pat=re.compile(r'^(?:v)?f(?:n?m)?(?:add|sub|mul|div|sqrt).*')
    for r in rows:
        if r['seq'] not in decoded: continue
        mn,asm=decoded[r['seq']]
        if mn in {'addsd','subsd','mulsd'}:
            scalar.append(r)
        elif fp_pat.match(mn) or mn.startswith(('vfm','fadd','fsub','fmul','fdiv','fsqrt')):
            unsupported.append((r['seq'],mn,asm))
    req(len(scalar)==cap['scalar_fp_count'],f'scalar metadata {len(scalar)} != {cap["scalar_fp_count"]}')
    # derive histogram of scalar itself, no expected constants
    scalar_hist=dict(collections.Counter(decoded[r['seq']][0] for r in scalar))
    return {
      'name':name,'errors':errors,'record_count':len(rows),'module_counts':module_counts,'bound_count':bind_count,
      'scalar_count':len(scalar),'scalar_hist':scalar_hist,'unsupported_fp':unsupported,
      'trace_sha256':hashlib.sha256(stream).hexdigest(),'pid':rows[0]['pid'],'ptid':rows[0]['ptid'],
      'pointers':cap['regions'][0]['pointers'],'output_bits':json.load(open(d/'harness_output.json'))['output_bits'],
      'gdb_version':cap.get('gdb_version'),'gdb_python':cap.get('gdb_python'),'wheel_sha256':cap.get('wheel_sha256'),
      'machine_mapping_read_by_tracer':cap.get('machine_mapping_read_by_tracer'),
      'pending_uncompleted_instruction':cap.get('pending_uncompleted_instruction'),
      'scalar_rows':[(r['module_sha256'],r['elf_address'],decoded[r['seq']][0],tuple(o['raw_bits'] for o in r['operands']),r.get('result_bits')) for r in scalar],
      'sequence':[(r['module_sha256'],r['elf_address'],r['bytes'],decoded[r['seq']][0]) for r in rows],
    }

def source_hash_check(name):
    d=ART/name
    ex=json.load(open(d/'execution.json'))
    out={}
    for rel,expected in ex.get('source_sha256_before_execution',{}).items():
        p=ROOT/rel
        out[rel]={'expected':expected,'actual':sha(p),'match':sha(p)==expected}
    return out

old=verify_capture('attempt-05')
fresh=verify_capture('closure-fresh-01')
summary={
 'binaries':{str(p.relative_to(ROOT)):sha(p) for p in MODULE_PATHS},
 'attempt05':{k:v for k,v in old.items() if k not in ('sequence','scalar_rows')},
 'fresh':{k:v for k,v in fresh.items() if k not in ('sequence','scalar_rows')},
 'old_fresh':{
   'sequence_equal':old['sequence']==fresh['sequence'],
   'scalar_rows_equal':old['scalar_rows']==fresh['scalar_rows'],
   'endpoint_equal':old['output_bits']==fresh['output_bits'],
   'trace_bytes_equal':(ART/'attempt-05/trace.jsonl').read_bytes()==(ART/'closure-fresh-01/trace.jsonl').read_bytes(),
   'trace_hashes':[old['trace_sha256'],fresh['trace_sha256']],
   'pid_equal':old['pid']==fresh['pid'],
   'pointer_equal':old['pointers']==fresh['pointers'],
 },
 'fresh_source_hashes_vs_snapshot':source_hash_check('closure-fresh-01'),
 'old_source_hashes_vs_snapshot':source_hash_check('attempt-05'),
}
path=pathlib.Path('/tmp/closure_reaudit_independent_results.json')
path.write_text(json.dumps(summary,indent=2))
print(json.dumps(summary,indent=2))
if old['errors'] or fresh['errors']:
    sys.exit(1)
