import sys, pathlib, json, hashlib, shutil, tempfile, os, subprocess, importlib.util
SRC=pathlib.Path('/tmp/rt_closure/snapshot')
WORK=pathlib.Path('/tmp/resolver_reaudit_root')
if WORK.exists(): shutil.rmtree(WORK)
shutil.copytree(SRC,WORK)
sys.path.insert(0,str(WORK))
import runtime_trace.correspondence as c

attempt=WORK/'runtime_trace/artifacts/attempt-05'
forbidden_prefixes=('/home/otherside123/','/usr/lib/x86_64-linux-gnu/libc.so.6')
accesses=[]
orig_open=pathlib.Path.open
orig_stat=os.stat
orig_co=subprocess.check_output

def badpath(p):
    try:s=os.fspath(p)
    except TypeError:return False
    return any(str(s).startswith(x) for x in forbidden_prefixes)

def guarded_open(self,*a,**kw):
    if badpath(self):
        accesses.append(('open',str(self))); raise AssertionError('forbidden runtime path open: '+str(self))
    return orig_open(self,*a,**kw)

def guarded_stat(path,*a,**kw):
    if badpath(path):
        accesses.append(('stat',str(path))); raise AssertionError('forbidden runtime path stat: '+str(path))
    return orig_stat(path,*a,**kw)

def guarded_co(args,*a,**kw):
    vals=args if isinstance(args,(list,tuple)) else [args]
    for v in vals:
        if badpath(v):
            accesses.append(('subprocess',str(v))); raise AssertionError('forbidden runtime path subprocess: '+str(v))
    return orig_co(args,*a,**kw)

# 1: original artifact succeeds with old runtime paths inaccessible
pathlib.Path.open=guarded_open; os.stat=guarded_stat; subprocess.check_output=guarded_co
try:
    r=c.check(attempt,WORK)
    blocked_original={'verdict':r['verdict'],'forbidden_accesses':accesses.copy()}
finally:
    pathlib.Path.open=orig_open; os.stat=orig_stat; subprocess.check_output=orig_co

# helper to rehash mutated trace/capture
def rehash_artifact(out):
    cp=out/'capture.json'; tp=out/'trace.jsonl'
    cap=json.load(open(cp))
    rows=[json.loads(x) for x in tp.read_text().splitlines() if x.strip()]
    chain='0'*64
    lines=[]
    for row in rows:
        row.pop('chain',None)
        chain=hashlib.sha256(bytes.fromhex(chain)+json.dumps(row,sort_keys=True,separators=(',',':')).encode()).hexdigest()
        row['chain']=chain
        lines.append(json.dumps(row,separators=(',',':')))
    stream=('\n'.join(lines)+'\n').encode()
    tp.write_bytes(stream)
    cap['trace_sha256']=hashlib.sha256(stream).hexdigest(); cap['final_chain']=chain; cap['record_count']=len(rows)
    cp.write_text(json.dumps(cap,indent=2)+'\n')

# 2: replace all provenance module paths with nonexistent paths; SHA resolver should still pass
P=pathlib.Path('/tmp/resolver_paths_artifact')
if P.exists(): shutil.rmtree(P)
shutil.copytree(attempt,P)
cap=json.load(open(P/'capture.json'))
rows=[json.loads(x) for x in (P/'trace.jsonl').read_text().splitlines() if x.strip()]
repl={old:f'/definitely/not/present/{i}.so' for i,old in enumerate(cap['modules'])}
newmods={}
for old,m in cap['modules'].items():
    m=dict(m); m['path']=repl[old]; newmods[repl[old]]=m
cap['modules']=newmods
(P/'capture.json').write_text(json.dumps(cap,indent=2)+'\n')
for r in rows:
    r['module_path']=repl[r['module_path']]
    r['mapping']['path']=r['module_path']
(P/'trace.jsonl').write_text('\n'.join(json.dumps(r,separators=(',',':')) for r in rows)+'\n')
rehash_artifact(P)
path_rewrite_result=c.check(P,WORK)['verdict']

# 3: missing packaged libc full check
libc=WORK/'runtime_trace/frozen_binaries/libc.so.6'
backup=libc.with_suffix('.bak')
libc.rename(backup)
try:
    try: c.check(attempt,WORK); missing='UNEXPECTED_PASS'
    except Exception as e: missing=f'{type(e).__name__}: {e}'
finally: backup.rename(libc)

# 4: tampered packaged libc full check (tamper untraced tail byte)
b=bytearray(libc.read_bytes()); b[-1]^=1; libc.write_bytes(b)
try:
    try: c.check(attempt,WORK); mismatch='UNEXPECTED_PASS'
    except Exception as e: mismatch=f'{type(e).__name__}: {e}'
finally:
    shutil.copy2(SRC/'runtime_trace/frozen_binaries/libc.so.6',libc)

# 5: unregistered module SHA with a valid arbitrary runtime file, relevant bytes unchanged.
evil=pathlib.Path('/tmp/evil-libc.so.6')
b=bytearray((SRC/'runtime_trace/frozen_binaries/libc.so.6').read_bytes()); b[-1]^=2; evil.write_bytes(b)
evil_sha=hashlib.sha256(b).hexdigest()
U=pathlib.Path('/tmp/resolver_unknown_artifact')
if U.exists(): shutil.rmtree(U)
shutil.copytree(attempt,U)
cap=json.load(open(U/'capture.json'))
oldpath='/usr/lib/x86_64-linux-gnu/libc.so.6'; oldmod=cap['modules'].pop(oldpath)
oldmod['path']=str(evil); oldmod['sha256']=evil_sha
cap['modules'][str(evil)]=oldmod
(U/'capture.json').write_text(json.dumps(cap,indent=2)+'\n')
rows=[json.loads(x) for x in (U/'trace.jsonl').read_text().splitlines() if x.strip()]
for r in rows:
    if r['module_path']==oldpath:
        r['module_path']=str(evil); r['mapping']['path']=str(evil); r['module_sha256']=evil_sha
(U/'trace.jsonl').write_text('\n'.join(json.dumps(r,separators=(',',':')) for r in rows)+'\n')
rehash_artifact(U)
try:
    c.check(U,WORK); unknown='UNEXPECTED_PASS'
except Exception as e: unknown=f'{type(e).__name__}: {e}'

out={'blocked_old_paths':blocked_original,'rewritten_nonexistent_paths':path_rewrite_result,'missing_packaged_binary':missing,'tampered_packaged_binary':mismatch,'unregistered_sha_with_existing_arbitrary_file':unknown,'evil_sha':evil_sha}
pathlib.Path('/tmp/resolver_reaudit_results.json').write_text(json.dumps(out,indent=2))
print(json.dumps(out,indent=2))
