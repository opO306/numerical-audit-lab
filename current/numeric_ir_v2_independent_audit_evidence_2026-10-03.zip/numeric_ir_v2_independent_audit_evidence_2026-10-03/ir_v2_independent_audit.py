from __future__ import annotations
import json, hashlib, math, struct, sys
from pathlib import Path
from fractions import Fraction

REPO=Path('/mnt/data/audit_ir_v2_repo')
V2DIR=REPO/'runtime_trace/numeric_ir/v2'
IRDIR=REPO/'runtime_trace/numeric_ir/artifacts'
FROZEN='48b91d0c45fd7f62dd09df4db28756e6f82c6bd464a040dc60ac1c924ed99780'
IR_SCHEMA='runtime-trace-numeric-ir-regular-1step-v1'
OUT_SCHEMA='numeric-ir-frozen-v2-regular-1step-v1'
K=4
TINY=2.0**-1074
MAP={'ADD_BINARY64':'ADD','SUB_BINARY64':'SUB','MUL_BINARY64':'MUL'}
ROOT={'LOAD_BITS','CONST_BITS','ZERO_BITS'}
STATE_KIND={'LOAD_BITS':'LOAD','CONST_BITS':'CONST','ZERO_BITS':'ZERO','COPY_BITS':'COPY','ARITHMETIC_RESULT':'ARITHMETIC_RESULT'}

def strict_pairs(pairs):
    d={}
    for k,v in pairs:
        if k in d: raise AssertionError(f'duplicate key {k}')
        d[k]=v
    return d

def load(path):
    return json.loads(path.read_bytes(), object_pairs_hook=strict_pairs)

def can(x): return json.dumps(x,sort_keys=True,separators=(',',':')).encode()

def sha(b): return hashlib.sha256(b).hexdigest()

def lane_bits(value, offset):
    w=value['width']; raw=value['raw_bits']
    b=int(raw,16).to_bytes(w,'little')
    lane=b[offset:offset+8]
    if len(lane)!=8: raise AssertionError('short lane')
    f=struct.unpack('<d',lane)[0]
    if not math.isfinite(f): raise AssertionError('nonfinite lane')
    return f"0x{int.from_bytes(lane,'little'):016x}"

def bits_fraction(bits_hex):
    u=int(bits_hex,16)
    s=-1 if (u>>63) else 1
    e=(u>>52)&0x7ff; frac=u&((1<<52)-1)
    if e==0x7ff: raise AssertionError('nonfinite bits')
    if e==0:
        if frac==0: return Fraction(0)
        mant=frac; power=-1022-52
    else:
        mant=(1<<52)|frac; power=e-1023-52
    q=Fraction(mant)
    if power>=0: q*=1<<power
    else: q/=1<<(-power)
    return s*q

def up(v):
    if math.isnan(v): return math.inf
    return math.nextafter(v,math.inf)

def up_q(q):
    f=float(q)
    return f if Fraction(f)>=q else math.nextafter(f,math.inf)

def rnd_err(c): return up(abs(c)*2.0**-52+TINY)

class Form:
    __slots__=('coef','box')
    def __init__(self,coef,box): self.coef=list(coef); self.box=box
    def rad(self):
        s=self.box
        for c in self.coef: s=up(s+abs(c))
        return s

def lin(a,b,sb,rho):
    coef=[]; extra=0.0
    for ca,cb in zip(a.coef,b.coef):
        c=ca+sb*cb; coef.append(c); extra=up(extra+rnd_err(c))
    return Form(coef, up(up(up(a.box+b.box)+extra)+rho))

def mul(xv,yv,a,b,rho):
    coef=[]; extra=0.0
    for ca,cb in zip(a.coef,b.coef):
        t1=xv*cb; t2=yv*ca; c=t1+t2; coef.append(c)
        extra=up(up(extra+rnd_err(t1))+up(rnd_err(t2)+rnd_err(c)))
    box=up(abs(xv)*b.box)+up(abs(yv)*a.box)
    box=up(up(box+up(a.rad()*b.rad()))+up(extra+rho))
    return Form(coef,box)

def fdoc(f):
    return {'coef':[float(c).hex() for c in f.coef],'box':float(f.box).hex()}

def compute_form(kind,out_bits,in0_bits,in1_bits,a,b):
    x=bits_fraction(in0_bits); y=bits_fraction(in1_bits); z=bits_fraction(out_bits)
    if kind=='ADD_BINARY64': return lin(a,b,1.0,up_q(abs(z-(x+y))))
    if kind=='SUB_BINARY64': return lin(a,b,-1.0,up_q(abs(z-(x-y))))
    if kind=='MUL_BINARY64': return mul(float(x),float(y),a,b,up_q(abs(z-x*y)))
    raise AssertionError(kind)

def reconstruct(label, ir_path, corr_path):
    raw=ir_path.read_bytes(); ir_sha=sha(raw); ir=load(ir_path)
    assert ir['schema']==IR_SCHEMA
    norm={'schema':ir['schema'],'operations':ir['operations'],'values':ir['values']}
    norm_sha=sha(can(norm))
    assert ir['source']['normalized_numeric_sha256']==norm_sha
    by={v['value_id']:v for v in ir['values']}
    assert len(by)==len(ir['values'])
    ops=ir['operations']
    assert all(o['ir_sequence']==i for i,o in enumerate(ops))
    assert all(ops[i]['trace_sequence'] < ops[i+1]['trace_sequence'] for i in range(len(ops)-1))
    result_idx={o['output_value_id']:i for i,o in enumerate(ops)}
    assert len(result_idx)==len(ops)
    kinds={k:0 for k in MAP.values()}
    for i,o in enumerate(ops):
        assert o['operation_kind'] in MAP; kinds[MAP[o['operation_kind']]]+=1
        for side in ('input0','input1','output'):
            v=by[o[side+'_value_id']]
            assert v['width']==8 and v['raw_bits']==o[side+'_raw_bits']
            assert lane_bits(v,0)==o[side+'_raw_bits']
        out=by[o['output_value_id']]
        assert out['producer_kind']=='ARITHMETIC_RESULT'
        assert out['producer']['trace_sequence']==o['trace_sequence']
        assert out['producer']['operation_kind']==o['operation_kind']
    assert {v['value_id'] for v in ir['values'] if v['producer_kind']=='ARITHMETIC_RESULT'}==set(result_idx)

    selected=set(); copy_source={}; visiting=set()
    def select(vid,off):
        key=(vid,off)
        if key in selected:return
        assert key not in visiting
        visiting.add(key)
        v=by[vid]; lane_bits(v,off)
        if v['producer_kind']=='COPY_BITS':
            covering=[]
            for e in v['source_slices']:
                ds=e['destination_offset']; de=ds+e['width']
                if ds<=off and off+8<=de: covering.append(e)
                elif off<de and ds<off+8: raise AssertionError(f'mixed lane {key}')
            assert len(covering)==1, (key,len(covering))
            e=covering[0]
            so=e['source_offset']+off-e['destination_offset']; sk=(e['value_id'],so)
            assert lane_bits(by[sk[0]],sk[1])==lane_bits(v,off)
            copy_source[key]=sk; select(*sk)
        visiting.remove(key);selected.add(key)
    for o in ops:
        select(o['input0_value_id'],0);select(o['input1_value_id'],0);select(o['output_value_id'],0)
    boundaries=[v for v in ir['values'] if v['producer'].get('role')=='boundary']
    for v in boundaries:
        assert v['width']%8==0
        for off in range(0,v['width'],8): select(v['value_id'],off)

    forms={}
    def resolve(key,before=None):
        if key in forms:return forms[key]
        v=by[key[0]]; kind=v['producer_kind']
        if kind in ROOT: f=Form([0.0]*K,0.0)
        elif kind=='COPY_BITS': f=resolve(copy_source[key],before)
        elif kind=='ARITHMETIC_RESULT':
            assert key in forms, f'arith unresolved {key}'
        else: raise AssertionError(kind)
        forms[key]=f;return f

    expected_ops=[]
    for i,o in enumerate(ops):
        k0=(o['input0_value_id'],0); k1=(o['input1_value_id'],0); ko=(o['output_value_id'],0)
        # Ensure arithmetic dependencies are earlier.
        for k in (k0,k1):
            # trace through copies until a non-copy root/result
            t=k; seen=set()
            while by[t[0]]['producer_kind']=='COPY_BITS':
                assert t not in seen; seen.add(t); t=copy_source[t]
            if by[t[0]]['producer_kind']=='ARITHMETIC_RESULT': assert result_idx[t[0]]<i
        a=resolve(k0,i); b=resolve(k1,i)
        out=compute_form(o['operation_kind'],o['output_raw_bits'],o['input0_raw_bits'],o['input1_raw_bits'],a,b)
        forms[ko]=out
        s0=f"state:{k0[0]}:byte:{k0[1]}";s1=f"state:{k1[0]}:byte:{k1[1]}";so=f"state:{ko[0]}:byte:{ko[1]}"
        expected_ops.append({**o,'v2_sequence':i,'v2_operation_kind':MAP[o['operation_kind']],
            'input0_state_id':s0,'input1_state_id':s1,'output_state_id':so,
            'input0_form':fdoc(a),'input1_form':fdoc(b),'output_form':fdoc(out)})

    expected_states=[]
    for key in sorted(selected):
        v=by[key[0]]; p=v['producer']; f=resolve(key)
        expected_states.append({
            'state_id':f"state:{key[0]}:byte:{key[1]}", 'value_id':key[0], 'byte_offset':key[1], 'width':8,
            'raw_center_bits':lane_bits(v,key[1]), 'form':fdoc(f), 'binding_kind':STATE_KIND[v['producer_kind']],
            'source_state_id': (f"state:{copy_source[key][0]}:byte:{copy_source[key][1]}" if key in copy_source else None),
            'producer_ir_sequence':result_idx.get(key[0]), 'phase':p['phase'], 'trace_sequence':p['trace_sequence']})

    expected_bound=[]
    for v in boundaries:
        p=v['producer']; assert p['trace_sequence'] is None and p['operand_index'] is None
        if v['producer_kind']=='LOAD_BITS': cls='CAPTURED_INPUT_ROOT'
        elif v['producer_kind']=='COPY_BITS' and p['phase']=='step':
            cls='CAPTURED_STATE_HANDOFF'
            for e in v['source_slices']:
                assert e['trace_sequence'] is None and e['source_operand_index'] is None
        else: raise AssertionError(('bad boundary',v['value_id'],v['producer_kind']))
        expected_bound.append({'value_id':v['value_id'],'phase':p['phase'],'boundary':p['boundary'],
            'producer_kind':v['producer_kind'],'classification':cls,'trace_sequence':None,
            'state_ids':[f"state:{v['value_id']}:byte:{off}" for off in range(0,v['width'],8)]})

    expected={'schema':OUT_SCHEMA,'source':{
        'audited_input_label':label,'numeric_ir_sha256':ir_sha,'normalized_numeric_sha256':norm_sha,
        'numeric_ir_schema':ir['schema'],'numeric_ir_source':ir['source'],
        'frozen_v2':{'module':'lab.v2_bound','operator':'step_forms','k':4,'lf_sha256':FROZEN,'imported_lf_sha256':FROZEN,'requested_lf_sha256':FROZEN}},
        'values':ir['values'],'boundaries':expected_bound,'state_bindings':expected_states,'operations':expected_ops}
    actual=load(corr_path)
    if expected!=actual:
        def first(a,b,path='$'):
            if type(a)!=type(b):return f'{path} type {type(a)} != {type(b)}'
            if isinstance(a,dict):
                if set(a)!=set(b): return f'{path} keys {set(a)^set(b)}'
                for k in sorted(a):
                    d=first(a[k],b[k],path+'.'+k)
                    if d:return d
            elif isinstance(a,list):
                if len(a)!=len(b):return f'{path} len {len(a)} != {len(b)}'
                for i,(x,y) in enumerate(zip(a,b)):
                    d=first(x,y,f'{path}[{i}]')
                    if d:return d
            elif a!=b:return f'{path}: {a!r} != {b!r}'
        raise AssertionError('full correspondence mismatch: '+str(first(expected,actual)))
    rawcorr=corr_path.read_bytes(); assert rawcorr==can(actual)
    comp=load(corr_path.parent/'completion_report.json')
    assert comp['correspondence_sha256']==sha(rawcorr)
    assert comp['source_numeric_ir_sha256']==ir_sha
    assert comp['source_normalized_numeric_sha256']==norm_sha
    assert comp['operation_count']==len(ops)
    assert comp['state_binding_count']==len(expected_states)
    assert comp['boundary_count']==len(expected_bound)
    return expected, {'label':label,'ir_sha':ir_sha,'norm_sha':norm_sha,'corr_sha':sha(rawcorr),'ops':len(ops),'states':len(expected_states),'boundaries':len(expected_bound),'kinds':kinds,'values':len(ir['values'])}

def normalized(out):
    x=json.loads(json.dumps(out))
    s=x['source']; s.pop('audited_input_label');s.pop('numeric_ir_sha256')
    for k in ('trace_sha256','final_chain','diagnostic'):s['numeric_ir_source'].pop(k)
    return x

results=[]; outs=[]
for label in ('attempt-05','closure-fresh-01'):
    out,info=reconstruct(label,IRDIR/label/'numeric_ir.json',V2DIR/'artifacts'/label/'correspondence.json')
    results.append(info);outs.append(out)
assert normalized(outs[0])==normalized(outs[1])
norm_sha=sha(can(normalized(outs[0])))
print(json.dumps({'verdict':'PASS','inputs':results,'normalized_correspondence_sha256':norm_sha},indent=2,sort_keys=True))
